#pragma once
#include <cstdint>

// Minimal ELF / dynamic-symbol helpers used to resolve and patch code in other
// loaded libraries (see inline_hook.cpp and xr_hook.cpp).
namespace elfutil {

// Find the runtime address of `sym` exported by the already-loaded library
// `libname` (e.g. "libopenxr_loader.so"). Returns nullptr if the library is not
// mapped or does not export the symbol.
void* find_export(const char* libname, const char* sym);

}
