cmake_minimum_required(VERSION 3.16)
project(komi_demo CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Point IMGUI_DIR at a Dear ImGui checkout (github.com/ocornut/imgui).
if(NOT DEFINED IMGUI_DIR)
    set(IMGUI_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../imgui")
endif()

find_package(glfw3 3.3 REQUIRED)
find_package(OpenGL REQUIRED)

add_executable(komi_demo
    komi_demo.cpp
    komi_theme.cpp
    ${IMGUI_DIR}/imgui.cpp
    ${IMGUI_DIR}/imgui_draw.cpp
    ${IMGUI_DIR}/imgui_tables.cpp
    ${IMGUI_DIR}/imgui_widgets.cpp
    ${IMGUI_DIR}/backends/imgui_impl_glfw.cpp
    ${IMGUI_DIR}/backends/imgui_impl_opengl3.cpp
)

target_include_directories(komi_demo PRIVATE ${IMGUI_DIR} ${IMGUI_DIR}/backends)
target_link_libraries(komi_demo PRIVATE glfw OpenGL::GL ${CMAKE_DL_LIBS})
