#pragma once

namespace xr_hook {
    // PLT-hooks xrGetInstanceProcAddr in libOVRPlugin.so, intercepts the XR
    // function pointers it resolves, and wraps xrReleaseSwapchainImage to
    // render ImGui into the eye textures each frame. Returns false if
    // libOVRPlugin.so isn't mapped or doesn't import xrGetInstanceProcAddr.
    bool init();

    void set_menu_open(bool open);
    bool menu_open();
    void toggle_menu();

    void inject_pointer(float x, float y, bool primaryDown);
}
