#include "xr_hook.h"
#include <jni.h>
JNIEXPORT jint JNI_OnLoad(JavaVM*, void*) { xr_hook::init(); return JNI_VERSION_1_6; }
