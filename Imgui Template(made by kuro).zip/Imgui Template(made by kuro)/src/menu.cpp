#include "menu.h"
#include "ui_audio.h"
#include "minecraft_regular_ttf.h"
#include <imgui.h>
#include <cmath>
#include <cfloat>

namespace {
constexpr float CW=640,CH=630,MX0=4,MY0=4,MX1=636,MY1=372,ROUND=28,PAD=12;
constexpr float TAB_H=34,TAB_TOP=26,TAB_GAP=4,SCROLL_W=14;
constexpr ImU32 WIN_BG=IM_COL32(48,51,58,255),WIN_EDGE=IM_COL32(150,156,166,255);
constexpr ImU32 TAB_BG=IM_COL32(42,46,53,255),TAB_HOV=IM_COL32(66,73,84,255);
constexpr ImU32 TAB_ACT=IM_COL32(72,112,174,255),TAB_TXT=IM_COL32(202,208,218,255);
constexpr ImU32 TEXT=IM_COL32(232,235,240,255),TEXT_DIM=IM_COL32(176,182,192,255);
constexpr ImU32 ACCENT=IM_COL32(104,166,224,255),ROW_EDGE=IM_COL32(88,94,104,255);
constexpr ImU32 SCROLL_BG=IM_COL32(32,35,41,255),SCROLL_THUMB=IM_COL32(176,184,196,255);
const char* labels[]={"Main","Movement","Soundboard","Misc"};
ImFont *titleFont=nullptr,*bodyFont=nullptr,*tabFont=nullptr,*smallFont=nullptr;
int page=0;
float pageScroll[4]={};
bool draggingScroll=false;

bool inside(ImVec2 a,ImVec2 b){ ImVec2 m=ImGui::GetIO().MousePos; return m.x>=a.x&&m.x<=b.x&&m.y>=a.y&&m.y<=b.y; }
float damp(float cur,float target,float dt,float tau){ return target+(cur-target)*expf(-dt/tau); }

float tab_bar(ImDrawList* d,float x,float y){
    static float markerX=0,markerW=0;
    float activeX=x,activeW=0;
    for(int i=0;i<4;i++){
        float w=tabFont->CalcTextSizeA(tabFont->FontSize,FLT_MAX,0,labels[i]).x+20;
        ImVec2 a(x,y),b(x+w,y+TAB_H);
        bool hover=inside(a,b),active=page==i;
        if(hover&&ImGui::IsMouseClicked(0)){
            page=i;
            ui_audio::play(ui_audio::Cue::Select);
        }
        d->AddRectFilled(a,b,active?TAB_ACT:(hover?TAB_HOV:TAB_BG),3);
        d->AddRect(a,b,ROW_EDGE,3,0,1);
        ImVec2 ts=tabFont->CalcTextSizeA(tabFont->FontSize,FLT_MAX,0,labels[i]);
        d->AddText(tabFont,tabFont->FontSize,ImVec2(x+(w-ts.x)*.5f,y+(TAB_H-ts.y)*.5f),active?IM_COL32_WHITE:TAB_TXT,labels[i]);
        if(active){ activeX=x; activeW=w; }
        x+=w+TAB_GAP;
    }
    if(markerW==0){ markerX=activeX; markerW=activeW; }
    markerX=damp(markerX,activeX,ImGui::GetIO().DeltaTime,.055f);
    markerW=damp(markerW,activeW,ImGui::GetIO().DeltaTime,.055f);
    d->AddRectFilled(ImVec2(markerX,y+TAB_H),ImVec2(markerX+markerW,y+TAB_H+3),ACCENT,1);
    d->AddLine(ImVec2(MX0+PAD,y+TAB_H+5),ImVec2(MX1-PAD,y+TAB_H+5),ROW_EDGE,1);
    return y+TAB_H+8;
}

void scrollbar(ImDrawList* d,float y0,float y1){
    float x=MX1-PAD-SCROLL_W;
    float trackH=y1-y0,contentH=480,visibleH=trackH,maxScroll=contentH-visibleH;
    float thumbH=trackH*(visibleH/contentH);
    if(thumbH<42) thumbH=42;
    float ty=y0+(trackH-thumbH)*(pageScroll[page]/maxScroll);
    ImVec2 trackA(x,y0),trackB(x+SCROLL_W,y1),thumbA(x,ty),thumbB(x+SCROLL_W,ty+thumbH);
    bool hover=inside(thumbA,thumbB);
    if(hover&&ImGui::IsMouseClicked(0)) draggingScroll=true;
    if(!ImGui::IsMouseDown(0)) draggingScroll=false;
    if(draggingScroll){
        float t=(ImGui::GetIO().MousePos.y-y0-thumbH*.5f)/(trackH-thumbH);
        if(t<0)t=0;if(t>1)t=1;pageScroll[page]=t*maxScroll;
    }
    float wheel=ImGui::GetIO().MouseWheel;
    if(wheel!=0) pageScroll[page]-=wheel*34;
    if(pageScroll[page]<0)pageScroll[page]=0;if(pageScroll[page]>maxScroll)pageScroll[page]=maxScroll;
    d->AddRectFilled(trackA,trackB,SCROLL_BG,SCROLL_W*.5f);
    d->AddRectFilled(thumbA,thumbB,hover?ACCENT:SCROLL_THUMB,SCROLL_W*.5f);
}
}

namespace menu {
void load_fonts(ImGuiIO& io){
    ImFontConfig c;c.FontDataOwnedByAtlas=false;c.OversampleH=2;c.OversampleV=1;
    auto add=[&](float px){return io.Fonts->AddFontFromMemoryTTF((void*)Minecraft_Regular_ttf,Minecraft_Regular_ttf_len,px,&c);};
    bodyFont=add(12);titleFont=add(12);tabFont=add(13);smallFont=add(11);io.FontDefault=bodyFont;
}

void apply_style(){
    ImGuiStyle& s=ImGui::GetStyle();s.WindowRounding=ROUND;s.FrameRounding=3;s.GrabRounding=2;s.ScrollbarRounding=6;
}

void render(bool open){
    static float alpha=0;static bool wasOpen=false;
    if(open!=wasOpen){ui_audio::play(open?ui_audio::Cue::Open:ui_audio::Cue::Close);wasOpen=open;}
    alpha=damp(alpha,open?1.f:0.f,ImGui::GetIO().DeltaTime,open?.055f:.045f);
    if(!open&&alpha<.004f)return;
    ImDrawList* d=ImGui::GetForegroundDrawList();
    auto fade=[&](ImU32 c){return (c&0x00FFFFFF)|((ImU32)(((c>>24)&255)*alpha)<<24);};
    d->AddRectFilled(ImVec2(MX0,MY0),ImVec2(MX1,MY1),fade(WIN_BG),ROUND);
    d->AddRect(ImVec2(MX0,MY0),ImVec2(MX1,MY1),fade(WIN_EDGE),ROUND,0,1.25f);
    d->AddText(titleFont,titleFont->FontSize,ImVec2(MX0+PAD,MY0+5),fade(TEXT),"BOMBED");
    float bodyY=tab_bar(d,MX0+PAD,MY0+TAB_TOP);
    float bodyX=MX0+PAD,bodyX1=MX1-PAD-SCROLL_W-10,bodyY1=MY1-PAD;
    d->PushClipRect(ImVec2(bodyX,bodyY),ImVec2(bodyX1,bodyY1),true);
    d->AddText(bodyFont,bodyFont->FontSize,ImVec2(bodyX,bodyY+8-pageScroll[page]),fade(TEXT_DIM),"EMPTY TEMPLATE PAGE");
    d->AddLine(ImVec2(bodyX,bodyY+28-pageScroll[page]),ImVec2(bodyX1,bodyY+28-pageScroll[page]),fade(ROW_EDGE),1);
    d->PopClipRect();
    scrollbar(d,bodyY+3,bodyY1);
    ImVec2 m=ImGui::GetIO().MousePos;
    if(m.x>=MX0&&m.x<=MX1&&m.y>=MY0&&m.y<=MY1){
        d->AddLine(ImVec2(m.x-5,m.y),ImVec2(m.x+5,m.y),fade(ACCENT),1.2f);
        d->AddLine(ImVec2(m.x,m.y-5),ImVec2(m.x,m.y+5),fade(ACCENT),1.2f);
        d->AddCircle(m,1.6f,fade(TEXT),10,1);
    }
}

void panel_extent(float& w,float& h){w=CW;h=CH;}
float main_band_height(){return 380;}
bool keyboard_rect(float&,float&,float&,float&){return false;}
}
