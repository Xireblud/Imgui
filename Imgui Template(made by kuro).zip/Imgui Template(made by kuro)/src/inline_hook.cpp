#include "inline_hook.h"

#include <cstdint>
#include <cstring>
#include <cstdlib>

#include <sys/mman.h>
#include <unistd.h>

// AArch64 inline detour: a 16-byte patch at the target
//     LDR x16, [pc, #8]
//     BR  x16
//     .quad replacement
// plus a trampoline that runs the relocated original prologue and jumps back to
// the instruction after the patch. `original` receives the trampoline, so
// calling it reaches the real code.
//
// The original project used ShadowHook (bytedance/android-inline-hook). This
// file is a self-contained equivalent covering what xr_hook.cpp needs: hook an
// arbitrary code address, fix up PC-relative prologues, hand back a callable
// trampoline.

namespace {

constexpr int  kPatchSize = 16;    // LDR + BR + 8-bit-of-address -> 16 bytes
constexpr int  kMaxBytes  = 16;    // relocate up to 16 bytes (4 instructions)
constexpr long kPageSizes = 4096;  // forced by AArch64 page granularity helpers

[[noreturn]] static inline void trap() { __builtin_trap(); }

static int64_t sext(int64_t v, int bits) {
    int64_t m = 1LL << (bits - 1);
    return (v ^ m) - m;
}

// ---- decode: which PC-relative instruction is this? -------------------------
static bool is_adrp(uint32_t i)      { return (i & 0x9F000000) == 0x90000000; }
static bool is_adr(uint32_t i)       { return (i & 0x9F000000) == 0x10000000; }
static bool is_b(uint32_t i)         { return (i & 0xFC000000) == 0x14000000; }
static bool is_bl(uint32_t i)        { return (i & 0xFC000000) == 0x94000000; }
static bool is_bcond(uint32_t i)     { return (i & 0xFF000010) == 0x54000000; }
// CBZ/CBNZ share bits[30:25]=011010; the op bit (24) separates Z from NZ.
// sf (bit 31) selects the register width.
static bool is_cb(uint32_t i)        { return (i & 0x7E000000) == 0x34000000; }
static bool is_cbz(uint32_t i)       { return is_cb(i) && !(i & 0x01000000); }
static bool is_cbnz(uint32_t i)      { return is_cb(i) &&  (i & 0x01000000); }
// TBZ/TBNZ share bits[30:25]=110110; op bit (24) separates Z from NZ.
static bool is_tb(uint32_t i)        { return (i & 0x7E000000) == 0x36000000; }
static bool is_tbz(uint32_t i)       { return is_tb(i) && !(i & 0x01000000); }
static bool is_tbnz(uint32_t i)      { return is_tb(i) &&  (i & 0x01000000); }
static bool is_ldr_literal(uint32_t i) { return ((i >> 24) & 0x3F) == 0x18; } // bits[29:24]==011000 (LDR W/X, LDRSW, PRFM literal)

// ---- decode: resolve the absolute target of a PC-relative insn --------------
static uint64_t adrp_target(uint32_t i, uint64_t pc) {
    uint32_t immlo = (i >> 29) & 0x3;
    uint32_t immhi = (i >> 5)  & 0x7FFFF;
    int64_t  imm   = sext((int64_t)((immhi << 2) | immlo), 21) << 12;
    return (uint64_t)(((int64_t)pc & ~0xFFF) + imm);
}
static uint64_t adr_target(uint32_t i, uint64_t pc) {
    uint32_t immlo = (i >> 29) & 0x3;
    uint32_t immhi = (i >> 5)  & 0x7FFFF;
    int64_t  imm   = sext((int64_t)((immhi << 2) | immlo), 21);
    return (uint64_t)((int64_t)pc + imm);
}
static uint64_t b_target(uint32_t i, uint64_t pc) {
    return (uint64_t)((int64_t)pc + sext((int64_t)(i & 0x03FFFFFF), 26) * 4);
}
static uint64_t cbz_target(uint32_t i, uint64_t pc) {
    return (uint64_t)((int64_t)pc + sext((int64_t)((i >> 5) & 0x7FFFF), 19) * 4);
}
static uint64_t tbz_target(uint32_t i, uint64_t pc) {
    return (uint64_t)((int64_t)pc + sext((int64_t)((i >> 5) & 0x3FFF), 14) * 4);
}
static uint64_t ldrl_target(uint32_t i, uint64_t pc) {
    return (uint64_t)((int64_t)pc + sext((int64_t)((i >> 5) & 0x7FFFF), 19) * 4);
}

// ---- encode: re-emit the instruction, preserving its non-address fields ----
// Each encoder keeps every bit that is NOT the branch/literal offset and only
// recomputes the offset for the relocation location.
static uint32_t enc_b(uint32_t i, int64_t target, uint64_t pc) {
    int64_t d = target - (int64_t)pc;
    if (d % 4 != 0) trap();
    int64_t imm26 = d / 4;
    if (imm26 < -(1L << 25) || imm26 >= (1L << 25)) trap();   // >128MB -> use ldr/br
    return (i & 0xFC000000u) | (uint32_t)(imm26 & 0x03FFFFFF);
}
static uint32_t enc_cbz(uint32_t i, int64_t target, uint64_t pc) {
    int64_t d = target - (int64_t)pc;
    if (d % 4 != 0) trap();
    int64_t imm19 = d / 4;
    if (imm19 < -(1L << 18) || imm19 >= (1L << 18)) trap();
    return (i & 0xFF00001Fu) | (uint32_t)((imm19 & 0x7FFFF) << 5);
}
static uint32_t enc_tbz(uint32_t i, int64_t target, uint64_t pc) {
    int64_t d = target - (int64_t)pc;
    if (d % 4 != 0) trap();
    int64_t imm14 = d / 4;
    if (imm14 < -(1L << 13) || imm14 >= (1L << 13)) trap();
    return (i & 0xFFF8001Fu) | (uint32_t)((imm14 & 0x3FFF) << 5);
}
static uint32_t enc_adrp(uint32_t i, uint64_t target, uint64_t pc) {
    int64_t raw  = (int64_t)target - ((int64_t)pc & ~0xFFF);
    int64_t pg   = raw >> 12;
    if (pg < -(1L << 20) || pg >= (1L << 20)) trap();         // >4GB -> ldr
    uint32_t imm = (uint32_t)(pg & 0x1FFFFF);
    return (i & 0x9F00001Fu)
         | ((imm & 0x3) << 29)
         | (((imm >> 2) & 0x7FFFF) << 5);
}
static uint32_t enc_adr(uint32_t i, uint64_t target, uint64_t pc) {
    int64_t d = (int64_t)target - (int64_t)pc;
    if (d < -(1L << 20) || d >= (1L << 20)) trap();
    uint32_t imm = (uint32_t)(d & 0x1FFFFF);
    return (i & 0x9F00001Fu)
         | ((imm & 0x3) << 29)
         | (((imm >> 2) & 0x7FFFF) << 5);
}
static uint32_t enc_ldrl(uint32_t i, uint64_t target, uint64_t pc) {
    int64_t d = (int64_t)target - (int64_t)pc;
    if (d % 4 != 0) trap();
    int64_t imm19 = d / 4;
    if (imm19 < -(1L << 18) || imm19 >= (1L << 18)) trap();
    return (i & 0xFF00001Fu) | (uint32_t)((imm19 & 0x7FFFF) << 5);
}

// Relocate one instruction from orig_pc to reloc_pc, fixing any PC-relative
// reference so it still points at the same absolute address. All other
// instructions are position-independent and copied verbatim.
static uint32_t relocate(uint32_t i, uint64_t orig_pc, uint64_t reloc_pc) {
    if (is_adrp(i)) return enc_adrp(i, adrp_target(i, orig_pc), reloc_pc);
    if (is_adr(i))  return enc_adr (i, adr_target (i, orig_pc), reloc_pc);
    if (is_bl(i))   return enc_b    (i, (int64_t)b_target(i, orig_pc), reloc_pc);
    if (is_b(i))    return enc_b    (i, (int64_t)b_target(i, orig_pc), reloc_pc);
    if (is_bcond(i))return enc_cbz  (i, (int64_t)cbz_target(i, orig_pc), reloc_pc);
    if (is_cbz(i))  return enc_cbz  (i, (int64_t)cbz_target(i, orig_pc), reloc_pc);
    if (is_cbnz(i)) return enc_cbz  (i, (int64_t)cbz_target(i, orig_pc), reloc_pc);
    if (is_tbz(i))  return enc_tbz  (i, (int64_t)tbz_target(i, orig_pc), reloc_pc);
    if (is_tbnz(i)) return enc_tbz  (i, (int64_t)tbz_target(i, orig_pc), reloc_pc);
    if (is_ldr_literal(i)) return enc_ldrl(i, ldrl_target(i, orig_pc), reloc_pc);
    return i;
}

} // anon

namespace inlinehook {

bool hook(void* target, void* replacement, void** original) {
    if (!target || !replacement) return false;

    const uint64_t target_pc = (uint64_t)target;
    const uint64_t page_mask = ~((uint64_t)sysconf(_SC_PAGESIZE) - 1);
    void* const    page      = (void*)(target_pc & page_mask);

    // Snapshot the original prologue before any writes.
    uint32_t orig[kMaxBytes / 4];
    memcpy(orig, target, kMaxBytes);
    int nbytes = kMaxBytes;          // exactly 4 instructions
    int ninsns = nbytes / 4;

    // One mmap holds: relocated prologue + an absolute jump back.
    const size_t tramp_len = (size_t)nbytes + 16;
    char* tramp = (char*)mmap(nullptr, tramp_len,
                              PROT_READ | PROT_WRITE,
                              MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (tramp == MAP_FAILED) return false;
    const uint64_t reloc_pc = (uint64_t)tramp;

    uint32_t* out = (uint32_t*)tramp;
    for (int i = 0; i < ninsns; i++)
        out[i] = relocate(orig[i], target_pc + (uint64_t)(i * 4), reloc_pc + (uint64_t)(i * 4));

    uint32_t* tail = out + ninsns;
    tail[0] = 0x58000050u;                       // LDR x16, [pc, #8]
    tail[1] = 0xD61F0200u;                       // BR  x16
    *(uint64_t*)(&tail[2]) = target_pc + nbytes; // .quad target+nbytes

    // Patch the target page. Ensure write access, patch, restore to RX.
    mprotect(page, sysconf(_SC_PAGESIZE), PROT_READ | PROT_WRITE | PROT_EXEC);
    memcpy(target, "\x50\x00\x00\x58\x00\x02\x1f\xd6", 8);   // LDR x16,#8 ; BR x16
    *(uint64_t*)((uint64_t)target + 8) = (uint64_t)replacement;
    mprotect(page, sysconf(_SC_PAGESIZE), PROT_READ | PROT_EXEC);

    // Trampoline becomes executable.
    mprotect(tramp, tramp_len, PROT_READ | PROT_EXEC);

    __builtin___clear_cache((char*)target, (char*)target + 16);
    __builtin___clear_cache(tramp, tramp + (ptrdiff_t)tramp_len);

    if (original) *original = tramp;
    return true;
}

} // namespace inlinehook
