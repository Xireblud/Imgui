#pragma once
struct ImGuiIO;
namespace menu {
void load_fonts(ImGuiIO&);
void apply_style();
void render(bool);
void panel_extent(float&,float&);
float main_band_height();
bool keyboard_rect(float&,float&,float&,float&);
}
