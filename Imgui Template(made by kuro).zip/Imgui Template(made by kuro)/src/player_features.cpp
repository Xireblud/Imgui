#include "player_features.h"
namespace features {
std::atomic<bool> flyEnabled{false},noclipArmed{false},noclipEnabled{false},espEnabled{false},spawnGun{false},prefabGun{false},aimRValid{false},camValid{false};
std::atomic<float> stickX{0},stickY{0},stickUp{0},triggerR{0},gripR{0},aimRX{0},aimRY{0},aimRZ{0},aimOX{0},aimOY{0},aimOZ{0},spawnGunRange{0};
std::mutex camMutex;
CamPose camPose;
std::vector<PlayerEntry> snapshot(){ return {}; }
void init(){}
}
