# VR Menu Template

A small Android OpenXR and ImGui menu shell.

Edit `src/menu.cpp` to rename the menu, tabs, and example controls. Pointer input,
vertical scrolling, interface sounds, and open/close behavior are already connected.

There are no game features, accounts, network tools, or IL2CPP game hooks.
