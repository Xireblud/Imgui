#pragma once

// arm64 inline-hook abstraction. The real project uses ShadowHook's native
// detour engine (Trampoline + 4-byte branch, with prologue relocation). This
// stub exposes the same surface xr_hook.cpp expects.
namespace inlinehook {

// Redirect `target` to `replacement`, saving the original entry point into
// *original so the caller can call through it later. Returns true on success.
bool hook(void* target, void* replacement, void** original);

}
