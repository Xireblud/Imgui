#pragma once
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
namespace features {
struct PlayerEntry { std::string name; float posX=0,posY=0,posZ=0,distance=0; bool isLocal=false; };
struct CamPose { float px=0,py=0,pz=0,rx=1,ry=0,rz=0,ux=0,uy=1,uz=0,fx=0,fy=0,fz=1; };
extern std::atomic<bool> flyEnabled,noclipArmed,noclipEnabled,espEnabled,spawnGun,prefabGun,aimRValid,camValid;
extern std::atomic<float> stickX,stickY,stickUp,triggerR,gripR,aimRX,aimRY,aimRZ,aimOX,aimOY,aimOZ,spawnGunRange;
extern std::mutex camMutex;
extern CamPose camPose;
std::vector<PlayerEntry> snapshot();
void init();
}
