#pragma once
#include <android/log.h>
#define AC_LOGI(...) __android_log_print(ANDROID_LOG_INFO,"vr_menu_template",__VA_ARGS__)
#define AC_LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"vr_menu_template",__VA_ARGS__)
#define AC_LOGI_ALWAYS(...) AC_LOGI(__VA_ARGS__)
#define AC_LOGE_ALWAYS(...) AC_LOGE(__VA_ARGS__)
