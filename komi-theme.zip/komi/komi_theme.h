// Komi — ImGui theme, v0.2
//
// Second design pass, matched to the reference: a white page holding one dark
// rounded card, a header bar (avatar, title + version, icon actions, accent
// button), a tab strip with a grey active pill, and collapsible category rows
// with nested item rows carrying bookmark / options icons.
#pragma once

#include "imgui.h"
#include <cstddef>

namespace komi {

// ---------------------------------------------------------------- palette
constexpr ImU32 kPage       = IM_COL32(255, 255, 255, 255); // page behind the card
constexpr ImU32 kCard       = IM_COL32( 12,  12,  12, 255);
constexpr ImU32 kHairline   = IM_COL32( 31,  31,  31, 255); // under the header
constexpr ImU32 kRowBg      = IM_COL32( 19,  19,  19, 255); // category header
constexpr ImU32 kRowBorder  = IM_COL32( 35,  35,  35, 255);
constexpr ImU32 kKidBg      = IM_COL32( 15,  15,  15, 255); // nested item row
constexpr ImU32 kKidLine    = IM_COL32( 30,  30,  30, 255);
constexpr ImU32 kText       = IM_COL32(245, 245, 245, 255);
constexpr ImU32 kTextDim    = IM_COL32(169, 169, 169, 255);
constexpr ImU32 kIcon       = IM_COL32(237, 237, 237, 255);
constexpr ImU32 kPill       = IM_COL32( 42,  42,  42, 255); // active tab
constexpr ImU32 kAccent     = IM_COL32( 88, 101, 242, 255); // call-to-action
constexpr ImU32 kAvatarA    = IM_COL32( 44,  58, 107, 255);
constexpr ImU32 kAvatarB    = IM_COL32(143, 162, 255, 255);

// Metrics in unscaled pixels.
constexpr float kHeaderHeight = 90.0f;
constexpr float kTabHeight    = 72.0f;
constexpr float kCatHeight    = 55.0f;
constexpr float kKidHeight    = 55.0f;
constexpr float kCardRounding = 16.0f;
constexpr float kRowRounding  = 12.0f;

struct HeaderHits {
    bool bookmark = false;
    bool mail     = false;
    bool panel    = false;
    bool gear     = false;
    bool action   = false; // the accent button on the right
};

struct ItemHits {
    bool bookmark = false;
    bool options  = false;
};

void ApplyTheme(float ui_scale = 1.0f);

// Fills the frame behind the card (call once per frame, before the card).
void Page(ImVec2 display_size);

// Card background only; draw your content on top of it.
void CardBackground(ImVec2 pos, ImVec2 size);

// Header bar: avatar, bold title with a chevron, version tag, four icon
// buttons on the right and one accent button. Returns which control was hit.
HeaderHits Header(const char* title, const char* version,
                  ImVec2 pos, float width,
                  const char* action_label);

// Tab strip with an active pill. Returns the selected index.
int TabBar(ImVec2 pos, float width,
           const char* const* tabs, int count, int selected);

// Collapsible category row with a count on the right.
bool CategoryRow(const char* label, int count, bool open);

// Nested row inside an open category. `first` / `last` round the block.
ItemHits ItemRow(const char* label, bool bookmarked, bool first, bool last);

// Small diagonal grip in the bottom-right of the card.
void ResizeGrip(ImVec2 pos);

} // namespace komi
