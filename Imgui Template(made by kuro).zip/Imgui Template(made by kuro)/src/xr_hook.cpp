#include "xr_hook.h"
#include "elf_util.h"
#include "inline_hook.h"
#include "menu.h"
#include "player_features.h"   // publish thumbstick for joystick-fly

#include <vulkan/vulkan.h>
#include <imgui.h>
#include <imgui_internal.h>   // ImDrawList::_ResetForNewFrame (standalone laser drawlist)
#include <imgui_impl_vulkan.h>

#include <dlfcn.h>
#include <time.h>
#include <cstring>
#include <cmath>
#include <cfloat>
#include <map>
#include <vector>
#include <mutex>
#include <android/log.h>

#include "ac_log.h"
#define LOG_TAG "ac_mod_quest/xr"
#define LOGI(...) AC_LOGI(__VA_ARGS__)
#define LOGE(...) AC_LOGE(__VA_ARGS__)

// ---- minimal OpenXR types (ABI-compatible, no OpenXR SDK needed) -----------
typedef struct XrInstance_T*  XrInstance;
typedef struct XrSession_T*   XrSession;
typedef struct XrSwapchain_T* XrSwapchain;
typedef int32_t  XrResult;
#define XR_SUCCESS 0
// XR_KHR_vulkan_enable (ext 26) uses 1000025000; the _enable2 variant (ext 91)
// uses 1000090000. The struct layout is identical, so accept either.
#define XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR  1000025000
#define XR_TYPE_GRAPHICS_BINDING_VULKAN2_KHR 1000090000
// vulkan_enable2 aliases this struct type rather than adding its own, so one
// value is correct under either extension.
#define XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR   1000025001
#define XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT 0x00000001ULL

struct XrBaseHeader { int32_t type; const void* next; };

struct XrSessionCreateInfo {
    int32_t     type;
    const void* next;
    uint64_t    createFlags;
    uint64_t    systemId;
};

struct XrGraphicsBindingVulkanKHR {
    int32_t          type;
    const void*      next;
    VkInstance       instance;
    VkPhysicalDevice physicalDevice;
    VkDevice         device;
    uint32_t         queueFamilyIndex;
    uint32_t         queueIndex;
};

struct XrSwapchainCreateInfo {
    int32_t     type;
    const void* next;
    uint64_t    createFlags;
    uint64_t    usageFlags;
    int64_t     format;
    uint32_t    sampleCount;
    uint32_t    width;
    uint32_t    height;
    uint32_t    faceCount;
    uint32_t    arraySize;
    uint32_t    mipCount;
};

struct XrSwapchainImageVulkanKHR {
    int32_t type;
    void*   next;
    VkImage image;
};

// ---- action/input types ----
typedef struct XrAction_T*    XrAction;
typedef struct XrActionSet_T* XrActionSet;
typedef uint64_t XrPath;
typedef int64_t  XrTime;
typedef uint32_t XrBool32;
#define XR_MAX_ACTION_NAME_SIZE 64
#define XR_MAX_LOCALIZED_ACTION_NAME_SIZE 128

struct XrActionCreateInfo {
    int32_t       type;
    const void*   next;
    char          actionName[XR_MAX_ACTION_NAME_SIZE];
    int32_t       actionType;   // 1=bool 2=float 3=vec2 4=pose
    uint32_t      countSubactionPaths;
    const XrPath* subactionPaths;
    char          localizedActionName[XR_MAX_LOCALIZED_ACTION_NAME_SIZE];
};
struct XrActionStateGetInfo {
    int32_t     type;
    const void* next;
    XrAction    action;
    XrPath      subactionPath;
};
struct XrVector2f { float x, y; };
struct XrActionStateFloat {
    int32_t type; void* next;
    float    currentState;
    XrBool32 changedSinceLastSync;
    XrTime   lastChangeTime;
    XrBool32 isActive;
};
struct XrActionStateBoolean {
    int32_t type; void* next;
    XrBool32 currentState;
    XrBool32 changedSinceLastSync;
    XrTime   lastChangeTime;
    XrBool32 isActive;
};
struct XrActionStateVector2f {
    int32_t type; void* next;
    XrVector2f currentState;
    XrBool32 changedSinceLastSync;
    XrTime   lastChangeTime;
    XrBool32 isActive;
};

// ---- action-set creation / binding-merge types (our own input) ----
#define XR_NULL_PATH 0ULL
#define XR_TYPE_ACTION_SET_CREATE_INFO 28
#define XR_TYPE_ACTION_CREATE_INFO 29
#define XR_TYPE_INTERACTION_PROFILE_SUGGESTED_BINDING 51
#define XR_TYPE_SESSION_ACTION_SETS_ATTACH_INFO 60
#define XR_TYPE_ACTIONS_SYNC_INFO 61
#define XR_TYPE_ACTION_STATE_GET_INFO 58
#define XR_TYPE_ACTION_STATE_BOOLEAN 23
#define XR_TYPE_ACTION_STATE_FLOAT 24
#define XR_TYPE_ACTION_STATE_VECTOR2F 25
#define XR_ACTION_TYPE_BOOLEAN_INPUT 1
#define XR_ACTION_TYPE_FLOAT_INPUT 2
#define XR_ACTION_TYPE_VECTOR2F_INPUT 3
#define XR_MAX_ACTION_SET_NAME_SIZE 64
#define XR_MAX_LOCALIZED_ACTION_SET_NAME_SIZE 128

struct XrActionSetCreateInfo {
    int32_t     type;
    const void* next;
    char        actionSetName[XR_MAX_ACTION_SET_NAME_SIZE];
    char        localizedActionSetName[XR_MAX_LOCALIZED_ACTION_SET_NAME_SIZE];
    uint32_t    priority;
};
struct XrActionSuggestedBinding {
    XrAction action;
    XrPath   binding;
};
struct XrInteractionProfileSuggestedBinding {
    int32_t     type;
    const void* next;
    XrPath      interactionProfile;
    uint32_t    countSuggestedBindings;
    const XrActionSuggestedBinding* suggestedBindings;
};
struct XrSessionActionSetsAttachInfo {
    int32_t     type;
    const void* next;
    uint32_t    countActionSets;
    const XrActionSet* actionSets;
};
struct XrActiveActionSet {
    XrActionSet actionSet;
    XrPath      subactionPath;
};
struct XrActionsSyncInfo {
    int32_t     type;
    const void* next;
    uint32_t    countActiveActionSets;
    const XrActiveActionSet* activeActionSets;
};

// ---- pose / space / view types (hand-anchored panel) ----
// Same hand-rolled-ABI approach as above: no OpenXR SDK in the tree, so these
// mirror the spec structs exactly. The struct-type numbers are the real
// XrStructureType values (verified against the ones already used above).
typedef struct XrSpace_T* XrSpace;
#define XR_TYPE_ACTION_SPACE_CREATE_INFO 38
#define XR_TYPE_SPACE_LOCATION           42
#define XR_TYPE_VIEW_LOCATE_INFO          6
#define XR_TYPE_VIEW                      7
#define XR_TYPE_VIEW_STATE               11
#define XR_ACTION_TYPE_POSE_INPUT         4
#define XR_SPACE_LOCATION_ORIENTATION_VALID_BIT 0x1
#define XR_SPACE_LOCATION_POSITION_VALID_BIT    0x2
#define XR_VIEW_STATE_ORIENTATION_VALID_BIT     0x1
#define XR_VIEW_STATE_POSITION_VALID_BIT        0x2

struct XrVector3f    { float x, y, z; };
struct XrQuaternionf { float x, y, z, w; };
struct XrPosef       { XrQuaternionf orientation; XrVector3f position; };
struct XrFovf        { float angleLeft, angleRight, angleUp, angleDown; };

struct XrActionSpaceCreateInfo {
    int32_t     type;
    const void* next;
    XrAction    action;
    XrPath      subactionPath;
    XrPosef     poseInActionSpace;
};
struct XrSpaceLocation {
    int32_t  type;
    void*    next;
    uint64_t locationFlags;
    XrPosef  pose;
};
struct XrViewLocateInfo {
    int32_t     type;
    const void* next;
    int32_t     viewConfigurationType;
    XrTime      displayTime;
    XrSpace     space;
};
struct XrViewState {
    int32_t  type;
    void*    next;
    uint64_t viewStateFlags;
};
struct XrView {
    int32_t type;
    void*   next;
    XrPosef pose;
    XrFovf  fov;
};

// ---- composition-layer types (xrEndFrame introspection) --------------------
// The app submits its finished eye images via xrEndFrame's projection layer,
// which records which swapchain+array-layer is each eye and the exact imageRect
// the world was drawn into (smaller than the swapchain under dynamic
// resolution). Real XrStructureType values.
#define XR_TYPE_FRAME_END_INFO                    12
#define XR_TYPE_COMPOSITION_LAYER_PROJECTION      35
#define XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW 48

struct XrOffset2Di { int32_t x, y; };
struct XrExtent2Di { int32_t width, height; };
struct XrRect2Di   { XrOffset2Di offset; XrExtent2Di extent; };
struct XrSwapchainSubImage {
    XrSwapchain swapchain;
    XrRect2Di   imageRect;
    uint32_t    imageArrayIndex;
};
struct XrCompositionLayerBaseHeader {
    int32_t     type;
    const void* next;
    uint64_t    layerFlags;   // XrCompositionLayerFlags (XrFlags64)
    XrSpace     space;
};
struct XrCompositionLayerProjectionView {
    int32_t             type;
    const void*         next;
    XrPosef             pose;
    XrFovf              fov;
    XrSwapchainSubImage subImage;
};
struct XrCompositionLayerProjection {
    int32_t     type;
    const void* next;
    uint64_t    layerFlags;
    XrSpace     space;
    uint32_t    viewCount;
    const XrCompositionLayerProjectionView* views;
};
struct XrFrameEndInfo {
    int32_t     type;
    const void* next;
    XrTime      displayTime;
    int32_t     environmentBlendMode;   // XrEnvironmentBlendMode (32-bit enum)
    uint32_t    layerCount;
    const XrCompositionLayerBaseHeader* const* layers;   // array of const pointers
};

// ---- QUAD LAYER: our own swapchain + composition layer ----------------------
// The UI is drawn ONCE, 1:1, into a swapchain we own and handed to the compositor
// as an XrCompositionLayerQuad with a pose and a size in meters. The runtime does
// the sampling at final display resolution with its own filtering, so glyphs stay
// sharp and ImGui's clip rects survive (lists can clip and scroll).
//
// None of it depends on how the game renders: no eye-assignment guessing, no
// dynamic-resolution rect matching, no multiview-vs-multipass branch. That makes
// the path portable to any OpenXR title. The eye-image compositing that does need
// all of those things is kept below as a fallback; it also costs a vkQueueWaitIdle
// per eye image, twice a frame.
#define XR_TYPE_SWAPCHAIN_CREATE_INFO         9
#define XR_TYPE_COMPOSITION_LAYER_QUAD        36
#define XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO  55
#define XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO     56
#define XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO  57
#define XR_SWAPCHAIN_USAGE_SAMPLED_BIT        0x00000020ULL
// Premultiplied source alpha. ImGui's Vulkan pipeline blends alpha with
// (srcAlpha=ONE, dstAlpha=ONE_MINUS_SRC_ALPHA), so drawing onto a transparent
// clear leaves rgb already multiplied by a, which is what this flag expects.
// Adding UNPREMULTIPLIED_ALPHA_BIT here would double-darken every edge.
#define XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT 0x00000002ULL
#define XR_EYE_VISIBILITY_BOTH                0

// XR_TIMEOUT_EXPIRED is a SUCCESS code (positive), not an error: the image stays
// acquired and the wait must be retried rather than treated as fatal.
#define XR_TIMEOUT_EXPIRED 1

typedef int64_t XrDuration;

struct XrExtent2Df { float width, height; };
struct XrCompositionLayerQuad {
    int32_t             type;
    const void*         next;
    uint64_t            layerFlags;
    XrSpace             space;
    int32_t             eyeVisibility;   // XrEyeVisibility (32-bit enum)
    XrSwapchainSubImage subImage;
    XrPosef             pose;            // +Z of this pose is the quad's facing normal
    XrExtent2Df         size;            // meters
};
struct XrSwapchainImageAcquireInfo { int32_t type; const void* next; };
struct XrSwapchainImageWaitInfo    { int32_t type; const void* next; XrDuration timeout; };
struct XrSwapchainImageReleaseInfo { int32_t type; const void* next; };

typedef void (*PFN_xrVoid)(void);
typedef XrResult (*PFN_GIPA)(XrInstance, const char*, PFN_xrVoid*);
typedef XrResult (*PFN_CreateSession)(XrInstance, const XrSessionCreateInfo*, XrSession*);
typedef XrResult (*PFN_CreateSwapchain)(XrSession, const XrSwapchainCreateInfo*, XrSwapchain*);
typedef XrResult (*PFN_DestroySwapchain)(XrSwapchain);
typedef XrResult (*PFN_Enum)(XrSwapchain, uint32_t, uint32_t*, void*);
typedef XrResult (*PFN_Acquire)(XrSwapchain, const void*, uint32_t*);
typedef XrResult (*PFN_Release)(XrSwapchain, const void*);
typedef XrResult (*PFN_Wait)(XrSwapchain, const XrSwapchainImageWaitInfo*);
typedef XrResult (*PFN_CreateAction)(XrActionSet, const XrActionCreateInfo*, XrAction*);
typedef XrResult (*PFN_GetFloat)(XrSession, const XrActionStateGetInfo*, XrActionStateFloat*);
typedef XrResult (*PFN_GetBool)(XrSession, const XrActionStateGetInfo*, XrActionStateBoolean*);
typedef XrResult (*PFN_GetVec2)(XrSession, const XrActionStateGetInfo*, XrActionStateVector2f*);
typedef XrResult (*PFN_StringToPath)(XrInstance, const char*, XrPath*);
typedef XrResult (*PFN_PathToString)(XrInstance, XrPath, uint32_t, uint32_t*, char*);
typedef XrResult (*PFN_CreateActionSet)(XrInstance, const XrActionSetCreateInfo*, XrActionSet*);
typedef XrResult (*PFN_Suggest)(XrInstance, const XrInteractionProfileSuggestedBinding*);
typedef XrResult (*PFN_Attach)(XrSession, const XrSessionActionSetsAttachInfo*);
typedef XrResult (*PFN_Sync)(XrSession, const XrActionsSyncInfo*);
typedef XrResult (*PFN_CreateActionSpace)(XrSession, const XrActionSpaceCreateInfo*, XrSpace*);
typedef XrResult (*PFN_LocateSpace)(XrSpace, XrSpace, XrTime, XrSpaceLocation*);
typedef XrResult (*PFN_LocateViews)(XrSession, const XrViewLocateInfo*, XrViewState*,
                                    uint32_t, uint32_t*, XrView*);
typedef XrResult (*PFN_EndFrame)(XrSession, const XrFrameEndInfo*);

// ---- state -----------------------------------------------------------------
namespace {

PFN_GIPA            o_GIPA            = nullptr;
PFN_CreateSession   o_CreateSession   = nullptr;
PFN_CreateSwapchain o_CreateSwapchain = nullptr;
PFN_DestroySwapchain o_DestroySwapchain = nullptr;
PFN_Enum            o_Enum            = nullptr;
PFN_Acquire         o_Acquire         = nullptr;
PFN_Release         o_Release         = nullptr;
PFN_Wait            o_Wait            = nullptr;  // captured, not wrapped: only WE call it
PFN_CreateAction    o_CreateAction    = nullptr;
PFN_GetFloat        o_GetFloat        = nullptr;
PFN_GetBool         o_GetBool         = nullptr;
PFN_GetVec2         o_GetVec2         = nullptr;
PFN_Suggest         o_Suggest         = nullptr;
PFN_Attach          o_Attach          = nullptr;
PFN_Sync            o_Sync            = nullptr;
PFN_LocateViews     o_LocateViews     = nullptr;  // wrapped: cache eye views + hand pose
PFN_EndFrame        o_EndFrame        = nullptr;  // wrapped: cache authoritative projection views

// Resolved to call, not wrapped: our own action set plumbing.
PFN_StringToPath    p_StringToPath    = nullptr;
PFN_PathToString    p_PathToString    = nullptr;
PFN_CreateActionSet p_CreateActionSet = nullptr;
PFN_CreateActionSpace p_CreateActionSpace = nullptr;
PFN_LocateSpace     p_LocateSpace     = nullptr;

XrInstance   g_xrInstance = nullptr;
XrSession    g_xrSession  = nullptr;
XrActionSet  g_actionSet  = nullptr;
XrAction     g_aClick     = nullptr;  // trigger -> mouse button
XrAction     g_aToggle    = nullptr;  // Y/B     -> show/hide menu
XrAction     g_aCursor    = nullptr;  // LEFT thumbstick  -> cursor / planar fly
XrAction     g_aCursorR   = nullptr;  // RIGHT thumbstick -> vertical fly (own action)
XrAction     g_aTrigR     = nullptr;  // RIGHT trigger -> slingshot-fly throttle (own action)
XrAction     g_aGripR     = nullptr;  // RIGHT squeeze -> spawn-in-hand / spawn-gun (own action)
XrAction     g_aGrip      = nullptr;  // right grip pose -> hand anchor
XrSpace      g_gripSpace  = nullptr;  // action space for the grip pose
XrAction     g_aAim       = nullptr;  // left aim pose -> menu anchor (hand menu)
XrSpace      g_aimSpace   = nullptr;  // action space for the left aim pose
XrAction     g_aAim2      = nullptr;  // right aim pose -> laser pointer
XrSpace      g_aim2Space  = nullptr;  // action space for the right aim pose
bool         g_inputReady = false;

// Latest eye views + right-hand pose, captured on the app's frame thread inside
// hk_LocateViews. Everything is expressed in the app's own reference space (the
// one it passes to xrLocateViews), so head and hand share one coordinate frame.
struct EyeView { XrPosef pose; XrFovf fov; };
EyeView  g_view[2]   = {};
uint32_t g_viewCount = 0;
bool     g_viewValid = false;
// View snapshots keyed by displayTime. The app can already be locating the
// next frame's views while the current one is being composited; drawing the
// panel with that newer prediction makes it shake with head motion, so the
// renderer uses the oldest snapshot that hasn't been submitted yet.
struct ViewSnap { XrTime t = 0; EyeView v[2] = {}; bool valid = false; };
ViewSnap g_snapCur, g_snapNext;
XrPosef  g_handPose  = {};
bool     g_handValid = false;
XrPosef  g_aimPose   = {};   // left-hand AIM pose (menu anchor)
bool     g_aimValid  = false;
XrPosef  g_aim2Pose  = {};   // right-hand AIM pose (laser origin/direction)
bool     g_aim2Valid = false;

// Authoritative per-eye projection info captured in hk_EndFrame. render_overlay
// matches a released swapchain+layer against these to learn WHICH eye it is and
// the REAL render rectangle (imageRect) to place/scale the panel by. That is
// independent of g_eyeW and of the swapchain width, which differ under dynamic
// resolution.
struct ProjView {
    XrSwapchain swapchain  = nullptr;
    uint32_t    arrayIndex = 0;
    int32_t     rectX = 0, rectY = 0, rectW = 0, rectH = 0;
    XrPosef     pose = {};
    XrFovf      fov  = {};
    bool        valid = false;
};
ProjView g_proj[2] = {};
bool     g_projValid = false;   // set once a projection layer is seen in xrEndFrame
XrSpace  g_projSpace = nullptr; // reference space the game renders/submits in

XrAction g_aGrab = nullptr;                 // right B: tap = toggle, hold = carry
// Tap B toggles the menu. Holding B floats it PANEL_CARRY_M in front of the
// right controller on the controller's own axes; releasing leaves it parked
// where it is.
struct Panel {
    XrVector3f posW{};                       // anchor in the app reference space
    XrVector3f rgt{1, 0, 0}, up{0, 1, 0}, nrm{0, 0, 1};   // world basis
    bool       haveAnchor = false;           // parked pose valid (persists closed)
    bool       carrying = false, prevB = false;
    bool       prevY = false;                // Y edge-detect (the menu toggle)
    double     bDownT = 0.0;                 // B press timestamp (tap vs hold)
} g_panel;
// Panel quad shared by the renderer and the laser ray-cast. Each one carries its
// own normal, because the two sit at DIFFERENT angles and g_panel.nrm cannot
// stand in for "the normal" once the canvas stops lying in a single plane.
struct Quad {
    XrVector3f anchor{}, rgt{}, up{}, nrm{};
    float halfW = 0.f, halfH = 0.f;          // meters
};
Quad g_quad;                     // the windows
Quad g_kbQuad;                   // the keyboard, pitched back to face the viewer
bool g_kbVisible = false;        // keyboard drawn this frame (gates layer + ray)
bool g_panelVis = false;
// Cleared for good if the runtime ever refuses the second quad layer. The
// keyboard then lives on the main surface, in-plane and untilted. That looks
// worse but stays usable, unlike an invisible keyboard that still takes clicks.
bool g_kbTilt3D = true;

// The main layer's slice of the canvas: just the band while the keyboard has its
// own surface, the WHOLE canvas once it does not and has to share this one.
static float main_band_px() {
    float PW, PH; menu::panel_extent(PW, PH);
    return g_kbTilt3D ? menu::main_band_height() : PH;
}

// Width of the WHOLE canvas in meters; the canvas holds the main window plus the
// info window beside it (the main window is ~70% of it). Sized so the body text
// reads comfortably with the panel parked at PANEL_FALLBACK_D; 0.64 read tight
// there. That makes it deliberately large at the 0.30 m carry distance, so carry
// it further out if that is too much. This is the one knob for menu size.
    constexpr float PANEL_W_M     = 0.52f;       // menu width in meters (small floating window)
// How far the keyboard is pitched back out of the windows' plane. 0 would leave
// it coplanar with them; 90 would lay it flat like a desk, edge-on and unreadable
// from above. 50 puts its face between the two, which is where a surface hanging
// BELOW eye level points at the eyes.
constexpr float KB_PITCH_DEG  = 50.f;
constexpr float KB_GAP_M      = 0.02f;       // hinge gap below the windows' bottom edge
constexpr float PANEL_CARRY_M = 0.30f;       // carry distance in front of the controller
constexpr float PANEL_FALLBACK_D = 0.90f;    // head-locked anchor before the first carry
constexpr double B_HOLD_SEC   = 0.18;        // B held longer than this = carry, shorter = toggle
constexpr bool  DRAW_LASER    = false;       // beam disabled while chasing a peripheral artifact
// A quad layer's front face is the +Z of its pose: an OpenXR viewer looks down
// -Z, so a quad placed in front of them with an identity orientation faces back
// at them. g_panel.nrm is already built pointing at the holder/head, so it maps
// straight onto +Z. If a runtime ever disagreed the panel would read mirrored or
// vanish; flipping this negates right+normal, which corrects it.
constexpr bool  QUAD_FACE_FLIP = false;
constexpr bool  EYE_LAYER_SWAP = false;      // MULTIVIEW: array layer 0 = LEFT eye (OpenXR view0=left, confirmed by canted-left fov in logs)
constexpr bool  EYE_SWAPCHAIN_SWAP = false;  // MULTIPASS: flip if the two per-eye swapchains are made right-then-left

// cursor / edge-detect state (menu space = eye pixels)
float g_cursorX = -1.f, g_cursorY = -1.f;
bool  g_click = false;

// Laser-pointer ray, computed in update_panel() on the frame thread and read
// on the render side during swapchain release.
bool   g_rayOnPanel = false;          // aim ray currently inside the panel rect
float  g_rayPxX = 0.f, g_rayPxY = 0.f;  // hit in CANVAS PIXELS, whichever surface it landed on
struct LaserSeg { float x0, y0, x1, y1; bool valid; };
LaserSeg g_laser[2] = {};             // per-eye endpoints as eye-buffer fractions
double g_stickTime = -1e9;            // last thumbstick deflection (cursor fallback)
bool   g_cursorVis = true;            // draw the ImGui cursor this frame?

// Vulkan handles captured from xrCreateSession's graphics binding.
VkInstance       g_vkInstance = VK_NULL_HANDLE;
VkPhysicalDevice g_vkPhys     = VK_NULL_HANDLE;
VkDevice         g_vkDevice   = VK_NULL_HANDLE;
VkQueue          g_vkQueue    = VK_NULL_HANDLE;
uint32_t         g_queueFamily = 0;
bool             g_haveVk      = false;

struct SCInfo { VkFormat format; uint32_t w, h, layers; bool isEye; int eyeIdx; };
std::map<XrSwapchain, SCInfo>                 g_sc;      // create info
std::map<XrSwapchain, std::vector<VkImage>>   g_images;  // enumerated images
std::map<XrSwapchain, uint32_t>               g_index;   // last acquired
// MULTIPASS only: when each eye is its own arraySize==1 swapchain the layer loop
// can't tell them apart, so we pin each eye swapchain to an eye by creation order.
int g_nextEyeSwapchain = 0;

// Per-VkImage, per-layer framebuffer/view cache.
struct FB { std::vector<VkImageView> views; std::vector<VkFramebuffer> fbs; };
std::map<VkImage, FB> g_fb;

std::mutex g_mtx;

// ImGui / render objects.
bool            g_imguiInited = false;
VkRenderPass    g_renderPass  = VK_NULL_HANDLE;
VkDescriptorPool g_descPool   = VK_NULL_HANDLE;
VkCommandPool   g_cmdPool     = VK_NULL_HANDLE;
VkCommandBuffer g_cmd         = VK_NULL_HANDLE;
VkFormat        g_eyeFormat   = VK_FORMAT_UNDEFINED;
uint32_t        g_eyeW = 0, g_eyeH = 0;

bool   g_menuOpen = true;
double g_lastTime = 0.0;

// ---- quad-layer render target (the new primary path) -----------------------
// Our own swapchain, sized to the menu's layout so ImGui pixel == swapchain
// texel. Laid out slightly denser than the panel needs on screen, so the
// compositor's minify pass antialiases the text instead of magnifying it.
XrSwapchain              g_menuSC   = nullptr;
std::vector<VkImage>     g_menuImgs;
std::vector<VkImageView> g_menuViews;
std::vector<VkFramebuffer> g_menuFbs;
VkRenderPass             g_menuPass = VK_NULL_HANDLE;   // CLEARs to transparent
uint32_t                 g_menuW = 0, g_menuH = 0;
bool                     g_menuScTried = false;         // one-shot creation attempt
bool                     g_quadActive  = false;         // true = eye-image path is off
// Filled by render_menu_layer(), consumed by hk_EndFrame in the same call.
XrCompositionLayerQuad   g_quadLayer{};
bool                     g_quadReady = false;
XrCompositionLayerQuad   g_kbLayer{};            // the tilted keyboard surface
bool                     g_kbLayerReady = false;

} // anon

static double now_sec() {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}
static void ckvk(VkResult r, const char* what) {
    if (r != VK_SUCCESS) LOGE("%s -> VkResult %d", what, (int)r);
}

// ---- one-time ImGui/Vulkan setup (needs eye format known) ------------------
static bool build_render_objects() {
    // Render pass: single color attachment, LOAD the game's frame, add overlay.
    VkAttachmentDescription color{};
    color.format         = g_eyeFormat;
    color.samples        = VK_SAMPLE_COUNT_1_BIT;
    color.loadOp         = VK_ATTACHMENT_LOAD_OP_LOAD;
    color.storeOp        = VK_ATTACHMENT_STORE_OP_STORE;
    color.stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    color.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    color.initialLayout  = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    color.finalLayout    = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkAttachmentReference ref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sub{};
    sub.pipelineBindPoint    = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sub.colorAttachmentCount = 1;
    sub.pColorAttachments    = &ref;

    VkSubpassDependency deps[2]{};
    deps[0].srcSubpass = VK_SUBPASS_EXTERNAL;
    deps[0].dstSubpass = 0;
    deps[0].srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    deps[0].dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    deps[0].srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    deps[0].dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_COLOR_ATTACHMENT_READ_BIT;
    deps[1].srcSubpass = 0;
    deps[1].dstSubpass = VK_SUBPASS_EXTERNAL;
    deps[1].srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    deps[1].dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    deps[1].srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
    deps[1].dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_COLOR_ATTACHMENT_READ_BIT;

    VkRenderPassCreateInfo rp{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    rp.attachmentCount = 1; rp.pAttachments = &color;
    rp.subpassCount = 1; rp.pSubpasses = &sub;
    rp.dependencyCount = 2; rp.pDependencies = deps;
    if (vkCreateRenderPass(g_vkDevice, &rp, nullptr, &g_renderPass) != VK_SUCCESS) {
        LOGE("vkCreateRenderPass failed"); return false;
    }

    // Descriptor pool for ImGui's font/textures.
    VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 16};
    VkDescriptorPoolCreateInfo dp{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dp.flags = VK_DESCRIPTOR_POOL_CREATE_FREE_DESCRIPTOR_SET_BIT;
    dp.maxSets = 16; dp.poolSizeCount = 1; dp.pPoolSizes = &ps;
    if (vkCreateDescriptorPool(g_vkDevice, &dp, nullptr, &g_descPool) != VK_SUCCESS) {
        LOGE("vkCreateDescriptorPool failed"); return false;
    }

    // Command pool + one reusable command buffer.
    VkCommandPoolCreateInfo cp{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    cp.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    cp.queueFamilyIndex = g_queueFamily;
    if (vkCreateCommandPool(g_vkDevice, &cp, nullptr, &g_cmdPool) != VK_SUCCESS) {
        LOGE("vkCreateCommandPool failed"); return false;
    }
    VkCommandBufferAllocateInfo ca{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    ca.commandPool = g_cmdPool; ca.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; ca.commandBufferCount = 1;
    if (vkAllocateCommandBuffers(g_vkDevice, &ca, &g_cmd) != VK_SUCCESS) {
        LOGE("vkAllocateCommandBuffers failed"); return false;
    }
    return true;
}

static bool init_imgui(uint32_t imageCount) {
    if (!build_render_objects()) return false;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io    = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.DisplaySize = ImVec2((float)g_eyeW, (float)g_eyeH);
    io.FontGlobalScale = 1.0f;   // real Roboto TTF at native px (no ProggyClean upscaling)
    io.MouseDrawCursor = true;   // draw our own cursor (no OS pointer in VR)
    menu::load_fonts(io);        // build the font atlas from the embedded TTF
    menu::apply_style();

    ImGui_ImplVulkan_InitInfo ii{};
    ii.ApiVersion     = VK_API_VERSION_1_1;
    ii.Instance       = g_vkInstance;
    ii.PhysicalDevice = g_vkPhys;
    ii.Device         = g_vkDevice;
    ii.QueueFamily    = g_queueFamily;
    ii.Queue          = g_vkQueue;
    ii.DescriptorPool = g_descPool;
    ii.RenderPass     = g_renderPass;
    // The backend rotates vertex/index buffers per RenderDrawData CALL, and we
    // record up to 4 calls into one submit (panel + laser, per eye): the ring
    // must cover them all or a later call overwrites an earlier call's buffers
    // before the GPU reads them.
    ii.MinImageCount  = (imageCount < 2 ? 2 : imageCount) * 2;
    ii.ImageCount     = (imageCount < 2 ? 2 : imageCount) * 2;
    ii.MSAASamples    = VK_SAMPLE_COUNT_1_BIT;
    ii.CheckVkResultFn = [](VkResult r){ if (r) LOGE("imgui vk err %d", (int)r); };

    if (!ImGui_ImplVulkan_Init(&ii)) { LOGE("ImGui_ImplVulkan_Init failed"); return false; }

    g_lastTime  = now_sec();
    g_stickTime = g_lastTime;   // cursor visible for the first moments (discoverability)
    g_imguiInited = true;
    LOGI("ImGui Vulkan initialized (%dx%d fmt=%d imgs=%u)",
         g_eyeW, g_eyeH, (int)g_eyeFormat, imageCount);
    return true;
}

// Lazily create per-layer image views + framebuffers for a swapchain image,
// sized to that swapchain (there can be >1 eye swapchain at different sizes).
static FB& framebuffers_for(VkImage img, uint32_t layers, uint32_t w, uint32_t h) {
    auto it = g_fb.find(img);
    if (it != g_fb.end()) return it->second;

    FB fb;
    fb.views.resize(layers, VK_NULL_HANDLE);
    fb.fbs.resize(layers, VK_NULL_HANDLE);
    for (uint32_t l = 0; l < layers; l++) {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image    = img;
        vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
        vi.format   = g_eyeFormat;
        vi.components = {VK_COMPONENT_SWIZZLE_IDENTITY, VK_COMPONENT_SWIZZLE_IDENTITY,
                        VK_COMPONENT_SWIZZLE_IDENTITY, VK_COMPONENT_SWIZZLE_IDENTITY};
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, l, 1};
        ckvk(vkCreateImageView(g_vkDevice, &vi, nullptr, &fb.views[l]), "vkCreateImageView");

        VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fi.renderPass = g_renderPass;
        fi.attachmentCount = 1; fi.pAttachments = &fb.views[l];
        fi.width = w; fi.height = h; fi.layers = 1;
        ckvk(vkCreateFramebuffer(g_vkDevice, &fi, nullptr, &fb.fbs[l]), "vkCreateFramebuffer");
    }
    g_fb[img] = std::move(fb);
    return g_fb[img];
}

static void read_input(float w, float h, float dt);   // defined below
// vector/quat helpers defined with the panel math below
static XrVector3f vsub(XrVector3f a, XrVector3f b);
static XrVector3f vadd(XrVector3f a, XrVector3f b);
static XrVector3f vscale(XrVector3f a, float s);
static XrVector3f qconjrot(XrQuaternionf q, XrVector3f v);

// ---- render the overlay into one eye image ---------------------------------
static void render_overlay(VkImage img, uint32_t layers, uint32_t w, uint32_t h,
                           int eyeIdx, XrSwapchain sc, const ProjView* proj, bool projValid) {
    ImGuiIO& io = ImGui::GetIO();
    // The menu lays out in its own pixel space (panel_extent), NOT the eye
    // buffer's: the quad-layer path renders that space 1:1 into a swapchain of
    // exactly this size, and this fallback maps it through the plane below. One
    // coordinate system for both paths keeps the cursor math in read_input
    // identical either way.
    float PW, PH; menu::panel_extent(PW, PH);
    io.DisplaySize = ImVec2(PW, PH);
    double t       = now_sec();
    io.DeltaTime   = (float)(t - g_lastTime);
    if (io.DeltaTime <= 0.0f) io.DeltaTime = 1.0f / 72.0f;
    g_lastTime = t;

    // Controller input -> ImGui pointer. Only interactive while the panel is
    // actually drawn; otherwise park the mouse off-panel so nothing hovers or
    // clicks blind (trigger and sticks are shared with the game).
    read_input(PW, PH, io.DeltaTime);
    bool interact      = g_cursorVis && g_panelVis;
    io.MousePos        = interact ? ImVec2(g_cursorX, g_cursorY) : ImVec2(-1e6f, -1e6f);
    io.MouseDown[0]    = g_click && interact;
    io.MouseDrawCursor = g_menuOpen && interact;

    ImGui_ImplVulkan_NewFrame();
    ImGui::NewFrame();
    menu::render(g_menuOpen);           // always call: handles its own open/close fade
    ImGui::Render();
    ImDrawData* dd = ImGui::GetDrawData();
    if (!dd) return;

    // Keep the untransformed vertex positions; each eye re-transforms from
    // these (the transform below rewrites the buffers in place).
    static std::vector<std::vector<ImVec2>> pv;
    pv.resize(dd->CmdListsCount);
    for (int li = 0; li < dd->CmdListsCount; li++) {
        ImDrawList* dl = dd->CmdLists[li];
        pv[li].resize(dl->VtxBuffer.Size);
        for (int i = 0; i < dl->VtxBuffer.Size; i++) pv[li][i] = dl->VtxBuffer[i].pos;
    }

    FB& fb = framebuffers_for(img, layers, w, h);

    vkResetCommandBuffer(g_cmd, 0);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(g_cmd, &bi);

    bool recorded = false;
    for (uint32_t l = 0; l < layers; l++) {
        if (fb.fbs[l] == VK_NULL_HANDLE) continue;

        // Work out which eye this framebuffer is and what rectangle the game
        // rendered into by matching the released swapchain+array-layer against
        // the projection layer cached from xrEndFrame. That settles eye
        // assignment and dynamic-resolution scale, and skips swapchains the
        // game didn't actually submit for display.
        int     eye = -1;
        int32_t rX = 0, rY = 0, rW = 0, rH = 0;
        bool    haveRect = false;
        if (projValid) {
            for (int i = 0; i < 2; i++) {
                if (proj[i].valid && proj[i].swapchain == sc && proj[i].arrayIndex == l) {
                    eye = i;
                    rX = proj[i].rectX; rY = proj[i].rectY;
                    rW = proj[i].rectW; rH = proj[i].rectH;
                    haveRect = (rW > 0 && rH > 0);
                    break;
                }
            }
            if (eye < 0) continue;   // not a displayed projection eye -> don't composite
        } else {
            // Fallback before the first xrEndFrame: creation-order mapping + g_eyeW.
            if (layers >= 2) eye = EYE_LAYER_SWAP ? (int)(1u - l) : (int)l;
            else             eye = (eyeIdx >= 0)
                                 ? (EYE_SWAPCHAIN_SWAP ? (1 - eyeIdx) : eyeIdx) : 0;
            if (eye > 1) eye = 1;
        }

        if (!g_panelVis) continue;

        // Perspective reprojection: map each vertex onto the world quad, then
        // through this eye's pose and the submitted fov. It has to be the fov
        // from xrEndFrame rather than xrLocateViews: the runtime reports
        // asymmetric per-eye fovs but the game renders symmetric ones, and mixing
        // them splits the eyes by ~18 degrees. The pose comes from the snapshot
        // for the frame being composited, not the freshest locate.
        EyeView evp = g_snapCur.valid ? g_snapCur.v[eye] : g_view[eye];
        if (projValid && proj[eye].valid) evp.fov = proj[eye].fov;
        const float tL = tanf(evp.fov.angleLeft), tR = tanf(evp.fov.angleRight);
        const float tU = tanf(evp.fov.angleUp),   tD = tanf(evp.fov.angleDown);
        const float rXf = haveRect ? (float)rX : 0.f;
        const float rYf = haveRect ? (float)rY : 0.f;
        const float rWf = haveRect ? (float)rW : (float)g_eyeW;
        const float rHf = haveRect ? (float)rH : (float)g_eyeH;
        auto xform = [&](const ImVec2& a) -> ImVec2 {
            // Panel pixel space (0..PW, 0..PH, Y down) -> quad units [-1,1].
            float u = (a.x / PW) * 2.f - 1.f;
            float v = (a.y / PH) * 2.f - 1.f;
            XrVector3f P = vadd(g_quad.anchor,
                                vadd(vscale(g_quad.rgt,  u * g_quad.halfW),
                                     vscale(g_quad.up,  -v * g_quad.halfH)));
            XrVector3f e = qconjrot(evp.pose.orientation, vsub(P, evp.pose.position));
            float zc = -e.z; if (zc < 0.015f) zc = 0.015f;   // behind-eye guard
            float fx = (e.x / zc - tL) / (tR - tL);
            float fy = (tU - e.y / zc) / (tU - tD);
            return ImVec2(rXf + fx * rWf, rYf + fy * rHf);
        };
        for (int li2 = 0; li2 < dd->CmdListsCount; li2++) {
            ImDrawList* dl = dd->CmdLists[li2];
            for (int i = 0; i < dl->VtxBuffer.Size; i++)
                dl->VtxBuffer[i].pos = xform(pv[li2][i]);
            // Full-framebuffer scissors: the geometry already bounds the panel,
            // and clip rects mapped through the plane blow up when a corner
            // lands near the eye.
            for (int i = 0; i < dl->CmdBuffer.Size; i++)
                dl->CmdBuffer[i].ClipRect = ImVec4(0.f, 0.f, (float)w, (float)h);
        }
        dd->DisplayPos       = ImVec2(0, 0);
        dd->DisplaySize      = ImVec2((float)w, (float)h);
        dd->FramebufferScale = ImVec2(1, 1);

        VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
        rb.renderPass  = g_renderPass;
        rb.framebuffer = fb.fbs[l];
        rb.renderArea  = {{0, 0}, {w, h}};
        rb.clearValueCount = 0;
        vkCmdBeginRenderPass(g_cmd, &rb, VK_SUBPASS_CONTENTS_INLINE);
        ImGui_ImplVulkan_RenderDrawData(dd, g_cmd);

        // Laser beam, drawn from its own drawlist in raw eye pixels: the start
        // point sits much nearer than the panel plane, so it gets its own
        // per-eye projection instead of the panel transform.
        if (DRAW_LASER && g_panelVis && g_menuOpen && eye >= 0 && eye < 2 && g_laser[eye].valid) {
            const LaserSeg& L = g_laser[eye];
            float x0, y0, x1, y1;
            if (haveRect) {
                x0 = (float)rX + L.x0 * (float)rW; y0 = (float)rY + L.y0 * (float)rH;
                x1 = (float)rX + L.x1 * (float)rW; y1 = (float)rY + L.y1 * (float)rH;
            } else {
                x0 = L.x0 * (float)g_eyeW; y0 = L.y0 * (float)g_eyeH;
                x1 = L.x1 * (float)g_eyeW; y1 = L.y1 * (float)g_eyeH;
            }
            static ImDrawList* ldl = nullptr;
            if (!ldl) ldl = new ImDrawList(ImGui::GetDrawListSharedData());
            ldl->_ResetForNewFrame();
            ldl->PushClipRect(ImVec2(0, 0), ImVec2((float)w, (float)h), false);
            ldl->PushTextureID(io.Fonts->TexID);
            ldl->AddLine(ImVec2(x0, y0), ImVec2(x1, y1), IM_COL32(240, 196, 120, 130), 2.5f);
            ldl->AddCircleFilled(ImVec2(x1, y1), 4.0f, IM_COL32(240, 196, 120, 200), 12);
            ldl->PopTextureID();
            ldl->PopClipRect();
            ImDrawData ld;
            ld.Valid = true;
            ld.AddDrawList(ldl);
            ld.DisplayPos       = ImVec2(0, 0);
            ld.DisplaySize      = ImVec2((float)w, (float)h);
            ld.FramebufferScale = ImVec2(1, 1);
            ImGui_ImplVulkan_RenderDrawData(&ld, g_cmd);
        }

        vkCmdEndRenderPass(g_cmd);
        recorded = true;
    }

    vkEndCommandBuffer(g_cmd);
    if (!recorded) return;   // nothing matched (non-displayed swapchain) -> skip submit/stall

    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1; si.pCommandBuffers = &g_cmd;
    if (vkQueueSubmit(g_vkQueue, 1, &si, VK_NULL_HANDLE) == VK_SUCCESS)
        vkQueueWaitIdle(g_vkQueue);
    else
        LOGE("vkQueueSubmit failed");
}

// ---- ESP: world-locked boxes composited into the eye images -----------------
//
// ESP cannot use a quad layer. A quad is a flat panel at a fixed pose, and an ESP
// box has to sit ON a player who may be 30 m out and 90 degrees off to the side.
// So this draws into the game's own eye images, once per eye, with that eye's
// real projection.
//
// COORDINATE SPACES. Player positions come from Unity (world space); the eye
// poses come from OpenXR (the app's reference space). Unity's XR rig sits between
// them with a transform we never see, so handing Unity coordinates to project()
// would put every box somewhere wrong. Instead the il2cpp thread publishes the
// GAME camera's own basis (features::camPose) and all of this happens in
// CAMERA-LOCAL coordinates, where the rig transform cancels out: a Unity world
// delta projected onto that basis is the direction the eye is looking along. Two
// things still come from OpenXR, both rig-independent: the submitted per-eye fov,
// and the eye's offset from the head centre, which gives the boxes real stereo
// depth instead of pasting them at infinity.
//
// Unity is left-handed with +Z forward, OpenXR eye space right-handed with -Z
// forward; x and y agree, so the whole conversion is one negated z.
//
// The camera pose is sampled on the game's Update and the eye image is rendered
// on the render thread, so under fast head motion the boxes can trail by about a
// frame. Correcting that would mean reprojecting through the OpenXR pose delta,
// which needs the rig transform this design exists to avoid.
//
// Self-test: draws two synthetic targets at known camera-relative positions so the
// projection can be checked from an eye-buffer screenshot in an empty room.
// AHEAD-3m should land near centre and RIGHT-4m to its right, which pins down the
// handedness of the camera basis. Left in place (off) as the cheapest way to
// re-check the projection.
#define ESP_SELFTEST 0

namespace {
constexpr ImU32 ESP_BOX    = IM_COL32(120, 240, 160, 235);
constexpr ImU32 ESP_TEXT   = IM_COL32(228, 242, 234, 255);
constexpr ImU32 ESP_SHADOW = IM_COL32(  4,   8,   6, 195);
constexpr float ESP_HEAD_UP = 0.22f;   // meters above the head transform
constexpr float ESP_BODY_H  = 1.55f;   // meters below it, i.e. about the floor
}

// sRGB -> linear, for the same reason menu.cpp has A(): the eye images are
// R8G8B8A8_SRGB, so the GPU encodes on write and blends against a decoded
// destination. Handing it sRGB-authored bytes gets them encoded twice and the
// box comes out a washed-out mint instead of green.
static ImU32 esp_lin(ImU32 c) {
    static float lut[256];
    static bool  ready = false;
    if (!ready) {
        for (int i = 0; i < 256; ++i) {
            float v = (float)i / 255.f;
            lut[i] = (v <= 0.04045f) ? (v / 12.92f) : powf((v + 0.055f) / 1.055f, 2.4f);
        }
        ready = true;
    }
    int r = (int)((c >> IM_COL32_R_SHIFT) & 0xFF);
    int g = (int)((c >> IM_COL32_G_SHIFT) & 0xFF);
    int b = (int)((c >> IM_COL32_B_SHIFT) & 0xFF);
    float a = (float)((c >> IM_COL32_A_SHIFT) & 0xFF) / 255.f;   // coverage, never converted
    return ImGui::ColorConvertFloat4ToU32(ImVec4(lut[r], lut[g], lut[b], a));
}

static void render_esp(VkImage img, uint32_t layers, uint32_t w, uint32_t h,
                       XrSwapchain sc, const ProjView* proj, bool projValid) {
    // Two customers: ESP boxes and the spawn-gun laser. The laser is drawn
    // whenever the mode is armed and the grip is squeezed, independently of ESP.
    // They share this one eye-image pass because it is the only place that can
    // draw world-locked geometry.
    const bool espOn   = features::espEnabled.load() && features::camValid.load();
    // Both spawn guns share this beam, so the gate has to accept either. The
    // PREFAB gun's tick publishes spawnGunRange every frame just like the item
    // gun's does.
    const bool laserOn = (features::spawnGun.load() || features::prefabGun.load())
                         && features::gripR.load() > 0.4f
                         && features::aimRValid.load();
    if (!espOn && !laserOn) return;
    if (!g_imguiInited || !projValid || !g_viewValid) return;

    std::vector<features::PlayerEntry> pl = espOn ? features::snapshot()
                                                  : std::vector<features::PlayerEntry>{};

    features::CamPose C;
    { std::lock_guard<std::mutex> lk(features::camMutex); C = features::camPose; }

#if ESP_SELFTEST
    // TEMPORARY. Two targets at known camera-relative positions so the projection
    // can be checked from a screenshot with nobody else in the room: A is dead
    // ahead at 3 m, B is 1.5 m to the RIGHT at 4 m (~21 degrees off centre). If B
    // renders on the left the basis is mirrored; if neither appears the forward
    // axis is flipped and everything is being culled as behind the eye.
    {
        features::PlayerEntry a;
        a.name = "AHEAD-3m"; a.distance = 3.f;
        a.posX = C.px + C.fx*3.f; a.posY = C.py + C.fy*3.f; a.posZ = C.pz + C.fz*3.f;
        features::PlayerEntry b;
        b.name = "RIGHT-4m"; b.distance = 4.f;
        b.posX = C.px + C.fx*4.f + C.rx*1.5f;
        b.posY = C.py + C.fy*4.f + C.ry*1.5f;
        b.posZ = C.pz + C.fz*4.f + C.rz*1.5f;
        pl.push_back(a); pl.push_back(b);
    }
#endif

    if (pl.empty() && !laserOn) return;

    ImGuiIO& io  = ImGui::GetIO();
    ImFont* font = io.FontDefault ? io.FontDefault
                                  : (io.Fonts->Fonts.Size ? io.Fonts->Fonts[0] : nullptr);
    if (!font) return;

    // Head centre in the app's reference space, and from it each eye's offset.
    // That offset expressed in the eye's own axes is essentially (+/-ipd/2, 0, 0),
    // the shift camera-local coordinates need for that eye.
    const EyeView* vsrc = g_snapCur.valid ? g_snapCur.v : g_view;
    XrVector3f hc = vscale(vadd(vsrc[0].pose.position, vsrc[1].pose.position), 0.5f);

    FB& fb = framebuffers_for(img, layers, w, h);

    vkResetCommandBuffer(g_cmd, 0);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(g_cmd, &bi);

    bool recorded = false;
    int  drawnTotal = 0;
    for (uint32_t l = 0; l < layers; l++) {
        if (fb.fbs[l] == VK_NULL_HANDLE) continue;

        // Eye + render rectangle, resolved exactly the way render_overlay does it:
        // match the released swapchain + array layer against the projection layer
        // the game actually submitted. That settles eye assignment and picks up
        // dynamic resolution, and skips swapchains that aren't being displayed.
        int   eye = -1;
        float rXf = 0.f, rYf = 0.f, rWf = (float)g_eyeW, rHf = (float)g_eyeH;
        for (int i = 0; i < 2; i++) {
            if (proj[i].valid && proj[i].swapchain == sc && proj[i].arrayIndex == l) {
                eye = i;
                if (proj[i].rectW > 0 && proj[i].rectH > 0) {
                    rXf = (float)proj[i].rectX; rYf = (float)proj[i].rectY;
                    rWf = (float)proj[i].rectW; rHf = (float)proj[i].rectH;
                }
                break;
            }
        }
        if (eye < 0) continue;

        // The fov has to be the SUBMITTED one, not xrLocateViews': the runtime
        // reports asymmetric per-eye fovs while the game renders symmetric ones,
        // and mixing them shifts everything sideways by degrees.
        const XrFovf fov = proj[eye].fov;
        const float tL = tanf(fov.angleLeft), tR = tanf(fov.angleRight);
        const float tU = tanf(fov.angleUp),   tD = tanf(fov.angleDown);
        if (tR - tL < 1e-4f || tU - tD < 1e-4f) continue;
        XrVector3f off = qconjrot(vsrc[eye].pose.orientation,
                                  vsub(vsrc[eye].pose.position, hc));

        auto project_world = [&](float wx, float wy, float wz, ImVec2& out) -> bool {
            float dx = wx - C.px, dy = wy - C.py, dz = wz - C.pz;
            float lx = dx*C.rx + dy*C.ry + dz*C.rz;      // camera-local right
            float ly = dx*C.ux + dy*C.uy + dz*C.uz;      // camera-local up
            float lz = dx*C.fx + dy*C.fy + dz*C.fz;      // camera-local forward
            // -> OpenXR eye space (z flips), then shift from head centre to THIS eye
            float ex = lx - off.x, ey = ly - off.y, ez = -lz - off.z;
            float zc = -ez;
            if (zc < 0.15f) return false;                // behind the eye or inside it
            out = ImVec2(rXf + ((ex / zc - tL) / (tR - tL)) * rWf,
                         rYf + ((tU - ey / zc) / (tU - tD)) * rHf);
            return true;
        };

        static ImDrawList* edl = nullptr;
        if (!edl) edl = new ImDrawList(ImGui::GetDrawListSharedData());
        edl->_ResetForNewFrame();
        edl->PushClipRect(ImVec2(0, 0), ImVec2((float)w, (float)h), false);
        edl->PushTextureID(io.Fonts->TexID);

        int drawn = 0;
        for (const auto& p : pl) {
            if (p.isLocal) continue;
            // p.pos is the HEAD transform (see netplayer_head_pos), so the box
            // runs from a little above it down to roughly the player's feet.
            ImVec2 top, bot;
            if (!project_world(p.posX, p.posY + ESP_HEAD_UP, p.posZ, top)) continue;
            if (!project_world(p.posX, p.posY - ESP_BODY_H,  p.posZ, bot)) continue;
            // min/max rather than assuming top projects above bot: at extreme
            // angles on a very close player the two can swap, and a negative
            // height would silently drop the box instead of drawing it.
            float y0 = fminf(top.y, bot.y), y1 = fmaxf(top.y, bot.y);
            float bh = y1 - y0;
            if (bh < 8.f) continue;                      // too far to read anything
            float bw = bh * 0.42f;
            float cx = (top.x + bot.x) * 0.5f;
            ImVec2 mn(cx - bw*0.5f, y0), mx(cx + bw*0.5f, y1);
            if (mx.x < 0.f || mn.x > (float)w || mx.y < 0.f || mn.y > (float)h) continue;

            float th = bh > 220.f ? 3.f : (bh > 90.f ? 2.f : 1.5f);
            // Dark line just outside the bright one. A thin green rect vanishes
            // against a lit wall; the outline keeps it readable on any background.
            edl->AddRect(ImVec2(mn.x - 1.f, mn.y - 1.f), ImVec2(mx.x + 1.f, mx.y + 1.f),
                         esp_lin(ESP_SHADOW), 0.f, 0, th);
            edl->AddRect(mn, mx, esp_lin(ESP_BOX), 0.f, 0, th);

            char lbl[96];
            snprintf(lbl, sizeof(lbl), "%s  %.0fm", p.name.c_str(), p.distance);
            float fs = bh * 0.16f;
            if (fs < 13.f) fs = 13.f;
            if (fs > 30.f) fs = 30.f;
            ImVec2 ts = font->CalcTextSizeA(fs, FLT_MAX, 0.f, lbl);
            ImVec2 tp(cx - ts.x*0.5f, mn.y - ts.y - 5.f);
            edl->AddText(font, fs, ImVec2(tp.x + 1.5f, tp.y + 1.5f), esp_lin(ESP_SHADOW), lbl);
            edl->AddText(font, fs, tp, esp_lin(ESP_TEXT), lbl);
            drawn++;
        }
        // ---- spawn-gun laser ------------------------------------------------
        // Pure head-local math: origin and direction are published in that frame,
        // and `off` converts to this eye. Unity is never consulted, so the beam is
        // correct even before the game camera resolves. The far end is where the
        // item will be placed, so the marker shows the actual aim point.
        if (laserOn) {
            float ox = features::aimOX.load(), oy = features::aimOY.load(), oz = features::aimOZ.load();
            float dx = features::aimRX.load(), dy = features::aimRY.load(), dz = features::aimRZ.load();
            float range = features::spawnGunRange.load();
            auto proj_head = [&](float px, float py, float pz, ImVec2& out) -> bool {
                float ex = px - off.x, ey = py - off.y, ez = pz - off.z;
                float zc = -ez;
                if (zc < 0.05f) return false;
                out = ImVec2(rXf + ((ex / zc - tL) / (tR - tL)) * rWf,
                             rYf + ((tU - ey / zc) / (tU - tD)) * rHf);
                return true;
            };
            // Segmented rather than one line: a straight 3D segment is straight in
            // screen space too, but projecting only the endpoints puts the whole beam
            // behind the eye the moment the near end is, and it pops out of existence.
            const int SEG = 12;
            ImVec2 prev; bool havePrev = false;
            for (int i = 0; i <= SEG; ++i) {
                float t = range * (float) i / (float) SEG;
                ImVec2 pt;
                if (!proj_head(ox + dx * t, oy + dy * t, oz + dz * t, pt)) { havePrev = false; continue; }
                if (havePrev) {
                    edl->AddLine(ImVec2(prev.x + 1.f, prev.y + 1.f), ImVec2(pt.x + 1.f, pt.y + 1.f),
                                 esp_lin(ESP_SHADOW), 3.0f);
                    edl->AddLine(prev, pt, esp_lin(IM_COL32(255, 186, 96, 235)), 2.2f);
                }
                prev = pt; havePrev = true;
            }
            ImVec2 tip;
            if (proj_head(ox + dx * range, oy + dy * range, oz + dz * range, tip)) {
                edl->AddCircleFilled(tip, 7.f, esp_lin(ESP_SHADOW), 16);
                edl->AddCircleFilled(tip, 5.f, esp_lin(IM_COL32(255, 200, 120, 245)), 16);
                edl->AddCircle(tip, 11.f, esp_lin(IM_COL32(255, 186, 96, 200)), 20, 1.8f);
            }
            drawn++;   // make sure the pass is submitted even with no ESP boxes
        }

        edl->PopTextureID();
        edl->PopClipRect();
        if (!drawn) continue;
        drawnTotal += drawn;

        ImDrawData dd;
        dd.Valid = true;
        dd.AddDrawList(edl);
        dd.DisplayPos       = ImVec2(0, 0);
        dd.DisplaySize      = ImVec2((float)w, (float)h);
        dd.FramebufferScale = ImVec2(1, 1);

        VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
        rb.renderPass  = g_renderPass;      // LOAD_OP_LOAD: keeps the game's pixels
        rb.framebuffer = fb.fbs[l];
        rb.renderArea  = {{0, 0}, {w, h}};
        rb.clearValueCount = 0;
        vkCmdBeginRenderPass(g_cmd, &rb, VK_SUBPASS_CONTENTS_INLINE);
        ImGui_ImplVulkan_RenderDrawData(&dd, g_cmd);
        vkCmdEndRenderPass(g_cmd);
        recorded = true;
    }

    vkEndCommandBuffer(g_cmd);
    if (!recorded) return;

    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1; si.pCommandBuffers = &g_cmd;
    if (vkQueueSubmit(g_vkQueue, 1, &si, VK_NULL_HANDLE) == VK_SUCCESS) vkQueueWaitIdle(g_vkQueue);
    else LOGE("[esp] vkQueueSubmit failed");

    static double s_log = -1e9;
    if (now_sec() - s_log > 15.0) {   // throttled: don't flush the log ring buffer
        s_log = now_sec();
        LOGI("[esp] boxes=%d players=%zu cam=(%.2f,%.2f,%.2f) rect=%.0fx%.0f",
             drawnTotal, pl.size(), C.px, C.py, C.pz, (float)w, (float)h);
    }
}

// ---- hooked XR functions ---------------------------------------------------
static XrResult hk_CreateSession(XrInstance inst, const XrSessionCreateInfo* ci, XrSession* out) {
    // Walk the next-chain for the Vulkan graphics binding BEFORE creating.
    if (ci && !g_haveVk) {
        LOGI("hk_CreateSession: ci=%p next=%p sysId=%llu", (void*)ci, ci->next,
             (unsigned long long)ci->systemId);
        const XrBaseHeader* h = (const XrBaseHeader*)ci->next;
        int walked = 0;
        while (h && walked < 32) {
            LOGI("  chain[%d] @ %p type=%d", walked, (void*)h, h->type);
            if (h->type == XR_TYPE_GRAPHICS_BINDING_VULKAN_KHR ||
                h->type == XR_TYPE_GRAPHICS_BINDING_VULKAN2_KHR) {
                auto* gb = (const XrGraphicsBindingVulkanKHR*)h;
                g_vkInstance  = gb->instance;
                g_vkPhys      = gb->physicalDevice;
                g_vkDevice    = gb->device;
                g_queueFamily = gb->queueFamilyIndex;
                vkGetDeviceQueue(g_vkDevice, gb->queueFamilyIndex, gb->queueIndex, &g_vkQueue);
                g_haveVk = true;
                LOGI("captured Vulkan binding: inst=%p phys=%p dev=%p qf=%u qi=%u queue=%p",
                     (void*)g_vkInstance, (void*)g_vkPhys, (void*)g_vkDevice,
                     gb->queueFamilyIndex, gb->queueIndex, (void*)g_vkQueue);
                break;
            }
            h = (const XrBaseHeader*)h->next;
            walked++;
        }
        if (!g_haveVk) LOGE("xrCreateSession: no Vulkan graphics binding in next-chain");
    }
    return o_CreateSession(inst, ci, out);
}

static XrResult hk_CreateSwapchain(XrSession s, const XrSwapchainCreateInfo* ci, XrSwapchain* out) {
    XrResult r = o_CreateSwapchain(s, ci, out);
    if (r == XR_SUCCESS && ci && out) {
        bool color = (ci->usageFlags & XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT) != 0;
        bool isEye = color && ci->width >= 1000 && ci->height >= 1000;
        uint32_t layers = ci->arraySize ? ci->arraySize : 1;
        std::lock_guard<std::mutex> lk(g_mtx);
        // Multipass only (per-eye arraySize==1 swapchains): pin an eye by creation
        // order. Multiview (layers>=2) carries both eyes in one swapchain, so eye
        // comes from the array layer instead and eyeIdx stays -1.
        int eyeIdx = (isEye && layers < 2) ? ((g_nextEyeSwapchain++) & 1) : -1;
        SCInfo info{(VkFormat)ci->format, ci->width, ci->height, layers, isEye, eyeIdx};
        g_sc[*out] = info;
        LOGI("xrCreateSwapchain %p: %ux%u fmt=%d layers=%u usage=0x%llx eye=%d eyeIdx=%d",
             (void*)*out, ci->width, ci->height, (int)ci->format,
             info.layers, (unsigned long long)ci->usageFlags, isEye, eyeIdx);
        if (isEye) { g_eyeFormat = info.format; g_eyeW = ci->width; g_eyeH = ci->height; }
    }
    return r;
}

static XrResult hk_Enum(XrSwapchain sc, uint32_t cap, uint32_t* cnt, void* imgs) {
    XrResult r = o_Enum(sc, cap, cnt, imgs);
    if (r == XR_SUCCESS && imgs && cap > 0 && cnt && *cnt > 0) {
        auto* si = (XrSwapchainImageVulkanKHR*)imgs;
        std::vector<VkImage> v(*cnt);
        for (uint32_t i = 0; i < *cnt; i++) v[i] = si[i].image;
        std::lock_guard<std::mutex> lk(g_mtx);
        g_images[sc] = std::move(v);
    }
    return r;
}

static XrResult hk_Acquire(XrSwapchain sc, const void* info, uint32_t* idx) {
    XrResult r = o_Acquire(sc, info, idx);
    if (r == XR_SUCCESS && idx) {
        std::lock_guard<std::mutex> lk(g_mtx);
        g_index[sc] = *idx;
    }
    return r;
}

static XrResult hk_Release(XrSwapchain sc, const void* info) {
    VkImage img = VK_NULL_HANDLE;
    uint32_t layers = 1, w = 0, h = 0;
    bool eye = false;
    int  eyeIdx = -1;
    uint32_t imgCount = 3;
    ProjView projCopy[2]{};
    bool     projValid = false;

    {
        std::lock_guard<std::mutex> lk(g_mtx);
        auto sIt = g_sc.find(sc);
        if (sIt != g_sc.end() && sIt->second.isEye) {
            eye = true;
            layers = sIt->second.layers;
            eyeIdx = sIt->second.eyeIdx;
            w = sIt->second.w;
            h = sIt->second.h;
            auto imIt = g_images.find(sc);
            auto ixIt = g_index.find(sc);
            if (imIt != g_images.end() && ixIt != g_index.end() &&
                ixIt->second < imIt->second.size()) {
                img = imIt->second[ixIt->second];
                if (imIt->second.size() >= 2) imgCount = imIt->second.size();
            }
        }
        projCopy[0] = g_proj[0];
        projCopy[1] = g_proj[1];
        projValid   = g_projValid;
    }

    // FALLBACK ONLY. The quad layer is the real path; this eye-image compositing
    // runs only if creating our own swapchain failed outright. g_menuScTried gates
    // it so the two paths can never both drive ImGui in one frame, since two
    // NewFrame/Render pairs would corrupt the draw data. The first xrEndFrame
    // decides which one owns the menu, and it is always reached before this can
    // matter.
    if (g_menuScTried && !g_quadActive &&
        eye && g_haveVk && img != VK_NULL_HANDLE && g_eyeFormat != VK_FORMAT_UNDEFINED) {
        if (!g_imguiInited) init_imgui(imgCount);
        if (g_imguiInited) render_overlay(img, layers, w, h, eyeIdx, sc, projCopy, projValid);
    }

    // ESP runs on BOTH paths and has to composite into the eye images even while
    // the quad layer owns the menu, because a world-locked box cannot live on a
    // flat panel. It gets its own pass and builds a standalone draw list rather
    // than a second NewFrame/Render pair, so it never disturbs ImGui's frame.
    if (eye && g_haveVk && img != VK_NULL_HANDLE && g_eyeFormat != VK_FORMAT_UNDEFINED)
        render_esp(img, layers, w, h, sc, projCopy, projValid);

    return o_Release(sc, info);
}

static XrResult hk_DestroySwapchain(XrSwapchain sc) {
    // Tear down our per-image framebuffers/views before the runtime frees the
    // underlying VkImages (their handles may be recycled by a later swapchain).
    std::lock_guard<std::mutex> lk(g_mtx);
    auto imIt = g_images.find(sc);
    if (imIt != g_images.end() && g_haveVk) {
        for (VkImage img : imIt->second) {
            auto fbIt = g_fb.find(img);
            if (fbIt == g_fb.end()) continue;
            for (VkFramebuffer f : fbIt->second.fbs) if (f) vkDestroyFramebuffer(g_vkDevice, f, nullptr);
            for (VkImageView v : fbIt->second.views) if (v) vkDestroyImageView(g_vkDevice, v, nullptr);
            g_fb.erase(fbIt);
        }
    }
    g_images.erase(sc);
    g_index.erase(sc);
    g_sc.erase(sc);
    return o_DestroySwapchain(sc);
}

// ---- our own action set (menu input, merged into the app's session) --------
static XrPath path(const char* s) {
    XrPath p = XR_NULL_PATH;
    if (p_StringToPath && g_xrInstance) p_StringToPath(g_xrInstance, s, &p);
    return p;
}

static void init_input() {
    if (g_actionSet || !g_xrInstance || !o_GIPA) return;

    if (!p_CreateActionSet) o_GIPA(g_xrInstance, "xrCreateActionSet",  (PFN_xrVoid*)&p_CreateActionSet);
    if (!p_StringToPath)    o_GIPA(g_xrInstance, "xrStringToPath",     (PFN_xrVoid*)&p_StringToPath);
    if (!p_PathToString)    o_GIPA(g_xrInstance, "xrPathToString",     (PFN_xrVoid*)&p_PathToString);
    if (!o_CreateAction)    o_GIPA(g_xrInstance, "xrCreateAction",     (PFN_xrVoid*)&o_CreateAction);
    if (!p_CreateActionSpace) o_GIPA(g_xrInstance, "xrCreateActionSpace", (PFN_xrVoid*)&p_CreateActionSpace);
    if (!p_LocateSpace)     o_GIPA(g_xrInstance, "xrLocateSpace",      (PFN_xrVoid*)&p_LocateSpace);
    if (!p_CreateActionSet || !p_StringToPath || !o_CreateAction) {
        LOGE("init_input: missing fns cas=%p stp=%p ca=%p",
             (void*)p_CreateActionSet, (void*)p_StringToPath, (void*)o_CreateAction);
        return;
    }

    XrActionSetCreateInfo asci{XR_TYPE_ACTION_SET_CREATE_INFO};
    strncpy(asci.actionSetName, "bombed_menu", XR_MAX_ACTION_SET_NAME_SIZE - 1);
    strncpy(asci.localizedActionSetName, "Bombed Menu", XR_MAX_LOCALIZED_ACTION_SET_NAME_SIZE - 1);
    asci.priority = 0;
    XrResult r = p_CreateActionSet(g_xrInstance, &asci, &g_actionSet);
    if (r != XR_SUCCESS || !g_actionSet) { LOGE("xrCreateActionSet -> %d", r); g_actionSet = nullptr; return; }

    auto mk = [&](const char* nm, const char* loc, int type, XrAction* out) {
        XrActionCreateInfo aci{XR_TYPE_ACTION_CREATE_INFO};
        strncpy(aci.actionName, nm, XR_MAX_ACTION_NAME_SIZE - 1);
        strncpy(aci.localizedActionName, loc, XR_MAX_LOCALIZED_ACTION_NAME_SIZE - 1);
        aci.actionType = type; aci.countSubactionPaths = 0; aci.subactionPaths = nullptr;
        XrResult rr = o_CreateAction(g_actionSet, &aci, out);
        if (rr != XR_SUCCESS) LOGE("xrCreateAction %s -> %d", nm, rr);
    };
    mk("menu_click",  "Menu Click",  XR_ACTION_TYPE_FLOAT_INPUT,    &g_aClick);
    mk("menu_toggle", "Menu Toggle", XR_ACTION_TYPE_BOOLEAN_INPUT,  &g_aToggle);
    mk("menu_cursor", "Menu Cursor", XR_ACTION_TYPE_VECTOR2F_INPUT, &g_aCursor);
    // The RIGHT stick needs its OWN action. Binding both sticks to g_aCursor makes
    // OpenXR collapse them (last-moved hand wins), so the right stick would just
    // repeat the left's planar move. With a separate action, right Y = altitude.
    mk("fly_updown",  "Fly Up/Down", XR_ACTION_TYPE_VECTOR2F_INPUT, &g_aCursorR);
    // Its own action, NOT a second binding on g_aClick: one action bound to both
    // triggers gets collapsed by the runtime (last-moved hand wins), the same trap
    // the thumbsticks hit. Binding the right trigger to two DIFFERENT actions is
    // fine; that is the supported direction.
    mk("fly_throttle","Fly Throttle",XR_ACTION_TYPE_FLOAT_INPUT,    &g_aTrigR);
    mk("grip_right","Right Grip",   XR_ACTION_TYPE_FLOAT_INPUT,    &g_aGripR);
    mk("menu_grip",   "Menu Grip",   XR_ACTION_TYPE_POSE_INPUT,     &g_aGrip);
    mk("menu_grab",   "Menu Grab",   XR_ACTION_TYPE_BOOLEAN_INPUT,  &g_aGrab);
    mk("menu_aim",    "Menu Aim",    XR_ACTION_TYPE_POSE_INPUT,     &g_aAim);
    mk("menu_aim_r",  "Menu Aim R",  XR_ACTION_TYPE_POSE_INPUT,     &g_aAim2);
    LOGI("init_input: set=%p click=%p toggle=%p cursor=%p",
         (void*)g_actionSet, (void*)g_aClick, (void*)g_aToggle, (void*)g_aCursor);
}

static XrResult hk_Suggest(XrInstance inst, const XrInteractionProfileSuggestedBinding* sb) {
    g_xrInstance = inst;
    init_input();
    if (!g_actionSet || !g_aClick || !g_aToggle || !g_aCursor || !sb)
        return o_Suggest(inst, sb);

    // Only merge into touch-controller-family profiles. Our binding paths
    // (thumbstick/trigger/y/b) are valid only there, and a bad path would fail the
    // WHOLE call and break the game's bindings.
    bool touch = false;
    if (p_PathToString) {
        char prof[256]; uint32_t n = 0;
        if (p_PathToString(inst, sb->interactionProfile, sizeof(prof), &n, prof) == XR_SUCCESS)
            touch = strstr(prof, "touch") != nullptr;
    }
    if (!touch) return o_Suggest(inst, sb);

    XrActionSuggestedBinding mine[] = {
        {g_aClick,  path("/user/hand/right/input/trigger/value")},
        {g_aClick,  path("/user/hand/left/input/trigger/value")},
        {g_aToggle, path("/user/hand/left/input/y/click")},   // Y = sole toggle
        {g_aGrab,   path("/user/hand/right/input/b/click")},   // B = grab & move
        {g_aCursor,  path("/user/hand/left/input/thumbstick")},   // planar move + cursor
        {g_aCursorR, path("/user/hand/right/input/thumbstick")},  // Y = up/down while flying
        {g_aTrigR,   path("/user/hand/right/input/trigger/value")}, // slingshot throttle
        {g_aGripR,   path("/user/hand/right/input/squeeze/value")}, // spawn modes
        {g_aGrip,   path("/user/hand/right/input/grip/pose")},
        {g_aAim,    path("/user/hand/left/input/aim/pose")},   // menu anchor
        {g_aAim2,   path("/user/hand/right/input/aim/pose")},  // laser pointer
    };

    std::vector<XrActionSuggestedBinding> merged;
    merged.reserve(sb->countSuggestedBindings + 9);
    for (uint32_t i = 0; i < sb->countSuggestedBindings; i++) merged.push_back(sb->suggestedBindings[i]);
    // Require a non-null action too: a failed action-create must never push a
    // null-action binding, which would fail the whole suggest call.
    for (auto& b : mine) if (b.binding && b.action) merged.push_back(b);

    XrInteractionProfileSuggestedBinding m = *sb;
    m.countSuggestedBindings = (uint32_t)merged.size();
    m.suggestedBindings = merged.data();
    XrResult r = o_Suggest(inst, &m);
    if (r != XR_SUCCESS) { LOGE("merged suggest -> %d, app-only fallback", r); return o_Suggest(inst, sb); }
    LOGI("merged our bindings into a touch profile (total %u)", m.countSuggestedBindings);
    return r;
}

static XrResult hk_Attach(XrSession s, const XrSessionActionSetsAttachInfo* ai) {
    g_xrSession = s;
    if (!g_actionSet || !g_aClick || !g_aToggle || !g_aCursor || !ai)
        return o_Attach(s, ai);

    std::vector<XrActionSet> sets;
    sets.reserve(ai->countActionSets + 1);
    for (uint32_t i = 0; i < ai->countActionSets; i++) sets.push_back(ai->actionSets[i]);
    sets.push_back(g_actionSet);

    XrSessionActionSetsAttachInfo m = *ai;
    m.countActionSets = (uint32_t)sets.size();
    m.actionSets = sets.data();
    XrResult r = o_Attach(s, &m);
    if (r != XR_SUCCESS) { LOGE("merged attach -> %d, app-only fallback", r); g_actionSet = nullptr; return o_Attach(s, ai); }
    g_inputReady = true;
    LOGI("attached our action set (total %u sets)", m.countActionSets);

    // Now that our set is attached to the session, create the grip pose's action
    // space. Locating it needs the set active in xrSyncActions (hk_Sync handles
    // that), so from here the hand pose becomes available each frame.
    if (p_CreateActionSpace && g_aGrip && !g_gripSpace) {
        XrActionSpaceCreateInfo si{XR_TYPE_ACTION_SPACE_CREATE_INFO};
        si.action = g_aGrip;
        si.subactionPath = XR_NULL_PATH;
        si.poseInActionSpace.orientation = {0, 0, 0, 1};   // identity offset
        XrResult sr = p_CreateActionSpace(s, &si, &g_gripSpace);
        if (sr != XR_SUCCESS) { LOGE("xrCreateActionSpace(grip) -> %d", sr); g_gripSpace = nullptr; }
        else LOGI("created grip action space %p", (void*)g_gripSpace);
    }
    if (p_CreateActionSpace && g_aAim && !g_aimSpace) {
        XrActionSpaceCreateInfo si{XR_TYPE_ACTION_SPACE_CREATE_INFO};
        si.action = g_aAim;
        si.subactionPath = XR_NULL_PATH;
        si.poseInActionSpace.orientation = {0, 0, 0, 1};
        XrResult sr = p_CreateActionSpace(s, &si, &g_aimSpace);
        if (sr != XR_SUCCESS) { LOGE("xrCreateActionSpace(aim) -> %d", sr); g_aimSpace = nullptr; }
        else LOGI("created aim action space %p", (void*)g_aimSpace);
    }
    if (p_CreateActionSpace && g_aAim2 && !g_aim2Space) {
        XrActionSpaceCreateInfo si{XR_TYPE_ACTION_SPACE_CREATE_INFO};
        si.action = g_aAim2;
        si.subactionPath = XR_NULL_PATH;
        si.poseInActionSpace.orientation = {0, 0, 0, 1};
        XrResult sr = p_CreateActionSpace(s, &si, &g_aim2Space);
        if (sr != XR_SUCCESS) { LOGE("xrCreateActionSpace(aimR) -> %d", sr); g_aim2Space = nullptr; }
        else LOGI("created right aim action space %p", (void*)g_aim2Space);
    }
    return r;
}

static XrResult hk_Sync(XrSession s, const XrActionsSyncInfo* si) {
    if (!g_inputReady || !g_actionSet || !si) return o_Sync(s, si);

    std::vector<XrActiveActionSet> active;
    active.reserve(si->countActiveActionSets + 1);
    for (uint32_t i = 0; i < si->countActiveActionSets; i++) active.push_back(si->activeActionSets[i]);
    active.push_back({g_actionSet, XR_NULL_PATH});

    XrActionsSyncInfo m = *si;
    m.countActiveActionSets = (uint32_t)active.size();
    m.activeActionSets = active.data();
    XrResult r = o_Sync(s, &m);
    if (r != XR_SUCCESS) return o_Sync(s, si);
    return r;
}

// ---- worldspace panel: vector/quat math + per-frame anchor update ----------
static XrVector3f vsub(XrVector3f a, XrVector3f b){ return {a.x-b.x, a.y-b.y, a.z-b.z}; }
static XrVector3f vadd(XrVector3f a, XrVector3f b){ return {a.x+b.x, a.y+b.y, a.z+b.z}; }
static XrVector3f vscale(XrVector3f a, float s){ return {a.x*s, a.y*s, a.z*s}; }
static float      vdot(XrVector3f a, XrVector3f b){ return a.x*b.x + a.y*b.y + a.z*b.z; }
static float      vlen(XrVector3f a){ return sqrtf(vdot(a, a)); }
static XrVector3f vcross(XrVector3f a, XrVector3f b){
    return { a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x };
}
// Rotate v by quaternion q (a pose orientation maps eye/local -> reference).
static XrVector3f qrot(XrQuaternionf q, XrVector3f v){
    XrVector3f u{q.x, q.y, q.z};
    XrVector3f t = vscale(vcross(u, v), 2.0f);
    return vadd(vadd(v, vscale(t, q.w)), vcross(u, t));
}
// Rotate v by the conjugate of q (reference -> eye/local).
static XrVector3f qconjrot(XrQuaternionf q, XrVector3f v){
    return qrot(XrQuaternionf{-q.x, -q.y, -q.z, q.w}, v);
}
// World point A -> FRACTION (fx,fy) of eye e's buffer, [0,1]; false if behind.
// Resolution-independent on purpose: the game's eye buffer width fluctuates
// (1728 vs 2016 seen live), so a fixed g_eyeW must NOT be baked in here. The
// caller multiplies by each frame's actual width/height at draw time.
// Asymmetric-fov map: OpenXR eye looks down -Z, +Y up; fy flips to top-left.
static bool project(const EyeView& e, XrVector3f A, float& fx, float& fy){
    XrVector3f ev = qconjrot(e.pose.orientation, vsub(A, e.pose.position));
    if (ev.z > -0.05f) return false;
    float zc = -ev.z, u = ev.x / zc, vv = ev.y / zc;
    float tL = tanf(e.fov.angleLeft), tR = tanf(e.fov.angleRight);
    float tU = tanf(e.fov.angleUp),   tD = tanf(e.fov.angleDown);
    fx = (u  - tL) / (tR - tL);
    fy = (tU - vv) / (tU - tD);
    return true;
}

// Billboard basis facing the head; keeps the previous basis when the anchor
// sits directly above/below it.
static void panel_face_head(XrVector3f H, XrVector3f anchor) {
    XrVector3f n = vsub(H, anchor);
    float nl = vlen(n);
    if (nl < 1e-3f) return;
    n = vscale(n, 1.f / nl);
    XrVector3f r = vcross(XrVector3f{0, 1, 0}, n);
    float rl = vlen(r);
    if (rl < 1e-3f) return;
    g_panel.nrm = n;
    g_panel.rgt = vscale(r, 1.f / rl);
    g_panel.up  = vcross(g_panel.nrm, g_panel.rgt);
}

// Runs on the app frame thread from hk_LocateViews once the poses are cached:
// B tap/hold handling, carry/park anchor, quad + laser ray for the renderer.
static void update_panel(){
    if (!g_viewValid) { g_panelVis = false; return; }

    XrVector3f H   = vscale(vadd(g_view[0].pose.position, g_view[1].pose.position), 0.5f);
    XrVector3f fwd = qrot(g_view[0].pose.orientation, XrVector3f{0, 0, -1});

    auto read_bool = [](XrAction a) -> bool {
        if (!a || !g_inputReady || !o_GetBool || !g_xrSession) return false;
        XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO, nullptr, a, XR_NULL_PATH};
        XrActionStateBoolean st{XR_TYPE_ACTION_STATE_BOOLEAN};
        if (o_GetBool(g_xrSession, &gi, &st) != XR_SUCCESS || !st.isActive) return false;
        return st.currentState != 0;
    };

    // ---- Y (left controller) owns the menu entirely -------------------------
    // The whole menu is driven from ONE controller, like the reference menu, only
    // on the left instead of the right:
    //     tap Y   -> open / close
    //     hold Y  -> carry the panel in front of the LEFT controller; releasing
    //                parks it where it is (opens it first if it was closed)
    // Pointing and clicking stay on the right hand, since a panel anchored to the
    // same hand you aim with can't be pointed at. That leaves B free, which is
    // what no-clip uses.
    double tnow = now_sec();
    bool y = read_bool(g_aToggle);
    bool yRising = y && !g_panel.prevY, yFalling = !y && g_panel.prevY;
    if (yRising) g_panel.bDownT = tnow;
    if (y && !g_panel.carrying && (tnow - g_panel.bDownT) >= B_HOLD_SEC) {
        g_panel.carrying = true;
        g_menuOpen = true;               // grabbing it implies wanting to see it
    }
    if (yFalling) {
        if (g_panel.carrying) g_panel.carrying = false;   // park where it is
        else                  g_menuOpen = !g_menuOpen;   // it was a tap
    }
    g_panel.prevY = y;

    // ---- B (right controller) = hold for no-clip, once ARMED ----------------
    // Two-stage by request: the Movement tab arms it, B activates it. Holding B
    // with it unarmed does nothing, so B stays a normal game button until you
    // opt in. B is also a game button either way and the game still sees it.
    features::noclipEnabled.store(features::noclipArmed.load() && read_bool(g_aGrab));

    // ---- publish the right-hand aim ray for slingshot fly --------------------
    // Handed over in HEAD-LOCAL coordinates, because that is the only frame both
    // threads can agree on: the il2cpp side rotates it through the game camera's
    // basis to land in Unity world space. See player_features.h.
    if (g_aim2Valid && g_viewValid) {
        XrVector3f aimW = qrot(g_aim2Pose.orientation, XrVector3f{0, 0, -1});
        XrVector3f aimH = qconjrot(g_view[0].pose.orientation, aimW);
        features::aimRX.store(aimH.x);
        features::aimRY.store(aimH.y);
        features::aimRZ.store(aimH.z);
        // Origin too, relative to the head CENTRE (the midpoint of the eyes), so
        // the laser can be drawn entirely in head-local space by the eye pass.
        XrVector3f hc  = vscale(vadd(g_view[0].pose.position, g_view[1].pose.position), 0.5f);
        XrVector3f oH  = qconjrot(g_view[0].pose.orientation, vsub(g_aim2Pose.position, hc));
        features::aimOX.store(oH.x);
        features::aimOY.store(oH.y);
        features::aimOZ.store(oH.z);
        features::aimRValid.store(true);
    } else {
        features::aimRValid.store(false);
    }

    // Carried panel sits PANEL_CARRY_M along the aim ray and takes the controller
    // axes as its basis. It uses the LEFT aim pose so the panel follows the hand
    // that grabbed it; right-hand poses are the fallback only. If every pose drops
    // mid-carry the last one is kept.
    if (g_panel.carrying) {
        XrPosef cp{}; bool have = false;
        if      (g_aimValid)  { cp = g_aimPose;  have = true; }   // LEFT aim
        else if (g_aim2Valid) { cp = g_aim2Pose; have = true; }
        else if (g_handValid) { cp = g_handPose; have = true; }
        if (have) {
            g_panel.posW = vadd(cp.position,
                vscale(qrot(cp.orientation, XrVector3f{0, 0, -1}), PANEL_CARRY_M));
            g_panel.rgt  = qrot(cp.orientation, XrVector3f{1, 0, 0});
            g_panel.up   = qrot(cp.orientation, XrVector3f{0, 1, 0});
            g_panel.nrm  = qrot(cp.orientation, XrVector3f{0, 0, 1});  // faces holder
            g_panel.haveAnchor = true;
        }
    } else if (!g_panel.haveAnchor) {
        // Never parked yet: head-locked ahead until the first carry.
        g_panel.posW = vadd(H, vscale(fwd, PANEL_FALLBACK_D));
        panel_face_head(H, g_panel.posW);
    }

    XrVector3f anchor = g_panel.posW;
    XrVector3f rel = vsub(anchor, H);
    float dist = vlen(rel);

    {
        float PW, PH; menu::panel_extent(PW, PH);
        const float mPerPx = PANEL_W_M / PW;      // canvas pixels -> meters
        g_quad.anchor = anchor;
        g_quad.rgt    = g_panel.rgt;
        g_quad.up     = g_panel.up;
        g_quad.nrm    = g_panel.nrm;
        g_quad.halfW  = PANEL_W_M * 0.5f;
        // Aspect from the MAIN BAND, not the whole canvas. The rows below it
        // belong to the keyboard and are shown by a different layer, so counting
        // them here would stretch the windows over texels they never draw.
        g_quad.halfH  = main_band_px() * mPerPx * 0.5f;

        // ---- the keyboard's own surface ------------------------------------
        // Posed every frame whether or not it is shown, so the first frame of a
        // tab that has one does not get a stale pose. keyboard_rect fills the
        // rect unconditionally and returns only whether to show it.
        float kx, ky, kw, kh;
        g_kbVisible = menu::keyboard_rect(kx, ky, kw, kh);
        g_kbQuad.halfW = kw * mPerPx * 0.5f;
        g_kbQuad.halfH = kh * mPerPx * 0.5f;

        // Pitch about the panel's own RIGHT axis, so the keyboard's top edge
        // swings AWAY from the viewer and its bottom swings toward them. The face
        // then points up at a head that is above it, which a single flat quad
        // cannot do.
        const float p = KB_PITCH_DEG * 3.14159265f / 180.f, cp = cosf(p), sp = sinf(p);
        g_kbQuad.rgt = g_panel.rgt;
        g_kbQuad.up  = vsub(vscale(g_panel.up, cp), vscale(g_panel.nrm, sp));
        g_kbQuad.nrm = vadd(vscale(g_panel.up, sp), vscale(g_panel.nrm, cp));

        // Hinged at the windows' bottom edge and hanging from it, so pitching
        // pivots where the two surfaces meet rather than sliding the keyboard
        // through them. CENTRED on the panel: as its own surface the keyboard has
        // no reason to inherit the canvas-relative x it is laid out at, which is
        // only where the free canvas room happened to be.
        XrVector3f hinge = vsub(anchor, vscale(g_panel.up, g_quad.halfH + KB_GAP_M));
        g_kbQuad.anchor = vsub(hinge, vscale(g_kbQuad.up, g_kbQuad.halfH));
    }
    // Hide when a quad corner gets too close to (or behind) an eye plane, since
    // the renderer's z clamp would smear it otherwise. Hide and re-show at
    // different margins: with a single threshold, pitching the head with the panel
    // parked near the face makes it strobe on the boundary.
    static bool hidden = false;
    const float zLim = hidden ? -0.030f : -0.015f;
    bool ok = dist > (hidden ? 0.20f : 0.16f);
    for (int l = 0; ok && l < 2; l++) {
        EyeView ev = g_view[l];
        if (g_projValid && g_proj[l].valid) ev.fov = g_proj[l].fov;
        float fx, fy;
        if (!project(ev, anchor, fx, fy)) { ok = false; break; }
        for (int c = 0; ok && c < 4; c++) {
            XrVector3f corner = vadd(g_quad.anchor,
                vadd(vscale(g_quad.rgt, (c & 1) ? g_quad.halfW : -g_quad.halfW),
                     vscale(g_quad.up,  (c & 2) ? g_quad.halfH : -g_quad.halfH)));
            XrVector3f e = qconjrot(ev.pose.orientation, vsub(corner, ev.pose.position));
            if (e.z > zLim) ok = false;
        }
    }
    hidden = !ok;
    g_panelVis = ok;

    // ---- cursor ray: RIGHT aim pose vs the SAME quad that is rendered -------
    // Same hand that carries the panel; carry and point never overlap (hold B
    // to carry/park, release, then point at the parked panel).
    g_rayOnPanel = false;
    g_laser[0].valid = g_laser[1].valid = false;
    if (ok && g_menuOpen && g_aim2Valid) {
        XrVector3f O = g_aim2Pose.position;
        XrVector3f D = qrot(g_aim2Pose.orientation, XrVector3f{0, 0, -1});

        // One rectangle test, now that there are two rectangles at different
        // angles. Fills u,v in [-1,1] (+u right, +v up) and the world hit point.
        auto hit = [&](const Quad& q, float& u, float& v, XrVector3f& Pw) {
            float denom = vdot(D, q.nrm);
            if (fabsf(denom) <= 1e-4f) return false;      // ray parallel to the surface
            float t = vdot(vsub(q.anchor, O), q.nrm) / denom;
            if (t <= 0.f) return false;                   // surface is behind the controller
            Pw = vadd(O, vscale(D, t));
            XrVector3f rel = vsub(Pw, q.anchor);
            float lu = vdot(rel, q.rgt), lv = vdot(rel, q.up);
            if (fabsf(lu) > q.halfW || fabsf(lv) > q.halfH) return false;
            u = lu / q.halfW; v = lv / q.halfH;
            return true;
        };

        // Both surfaces map their hit into the SAME canvas pixel space, which is
        // what lets one cursor serve two surfaces at two angles: the menu code
        // downstream never learns that the keyboard is tilted, because by the
        // time the hit reaches it the tilt has already been undone.
        float PW, PH; menu::panel_extent(PW, PH);
        float u, v; XrVector3f Pw;
        bool got = false;
        if (hit(g_quad, u, v, Pw)) {
            g_rayPxX = (u * 0.5f + 0.5f) * PW;
            g_rayPxY = (0.5f - v * 0.5f) * main_band_px();
            got = true;
        } else if (g_kbVisible && g_kbTilt3D && hit(g_kbQuad, u, v, Pw)) {
            float kx, ky, kw, kh; menu::keyboard_rect(kx, ky, kw, kh);
            g_rayPxX = kx + (u * 0.5f + 0.5f) * kw;
            g_rayPxY = ky + (0.5f - v * 0.5f) * kh;
            got = true;
        }
        if (got) {
            g_rayOnPanel = true;
            // Laser segment (controller tip -> hit point) as per-eye buffer
            // fractions, through the same submitted-fov projection path the
            // panel rendering uses.
            XrVector3f tip = vadd(O, vscale(D, 0.03f));
            for (int l = 0; l < 2; l++) {
                EyeView ev = g_view[l];
                if (g_projValid && g_proj[l].valid) ev.fov = g_proj[l].fov;
                float ax, ay, bx, by;
                if (project(ev, tip, ax, ay) && project(ev, Pw, bx, by))
                    g_laser[l] = {ax, ay, bx, by, true};
            }
        }
    }
}

// The app locates its eyes every frame; we piggyback to cache the per-eye
// pose+fov (needed to project a world point to a screen pixel) and, in the same
// space and at the same predicted display time, the right-hand pose (the panel
// anchor). Doing the hand locate here keeps it on the app's frame thread.
static XrResult hk_LocateViews(XrSession s, const XrViewLocateInfo* li, XrViewState* vs,
                               uint32_t cap, uint32_t* cnt, XrView* views) {
    XrResult r = o_LocateViews(s, li, vs, cap, cnt, views);
    if (r != XR_SUCCESS || !li || cap == 0 || !views || !cnt || *cnt == 0) return r;

    // Only track locates done in the space the projection layer is submitted
    // in; the app also locates views in other reference spaces (eye offsets
    // etc.) and those poses are useless here.
    if (g_projSpace && li->space != g_projSpace) return r;

    uint32_t n = *cnt < 2 ? *cnt : 2;
    for (uint32_t i = 0; i < n; i++) { g_view[i].pose = views[i].pose; g_view[i].fov = views[i].fov; }
    g_viewCount = n;
    g_viewValid = vs && (vs->viewStateFlags & XR_VIEW_STATE_POSITION_VALID_BIT)
                     && (vs->viewStateFlags & XR_VIEW_STATE_ORIENTATION_VALID_BIT);
    if (g_viewValid) {
        XrTime T = li->displayTime;
        if (!g_snapCur.valid || T == g_snapCur.t) {
            g_snapCur.t = T; g_snapCur.v[0] = g_view[0]; g_snapCur.v[1] = g_view[1];
            g_snapCur.valid = true;
        } else if (T > g_snapCur.t) {
            g_snapNext.t = T; g_snapNext.v[0] = g_view[0]; g_snapNext.v[1] = g_view[1];
            g_snapNext.valid = true;
        }
    }

    if (g_viewValid && p_LocateSpace && g_gripSpace) {
        XrSpaceLocation loc{XR_TYPE_SPACE_LOCATION};
        if (p_LocateSpace(g_gripSpace, li->space, li->displayTime, &loc) == XR_SUCCESS &&
            (loc.locationFlags & XR_SPACE_LOCATION_POSITION_VALID_BIT)) {
            g_handPose  = loc.pose;
            g_handValid = true;
        } else {
            g_handValid = false;
        }
    }
    if (g_viewValid && p_LocateSpace && g_aimSpace) {
        XrSpaceLocation loc{XR_TYPE_SPACE_LOCATION};
        if (p_LocateSpace(g_aimSpace, li->space, li->displayTime, &loc) == XR_SUCCESS &&
            (loc.locationFlags & XR_SPACE_LOCATION_POSITION_VALID_BIT) &&
            (loc.locationFlags & XR_SPACE_LOCATION_ORIENTATION_VALID_BIT)) {
            g_aimPose  = loc.pose;
            g_aimValid = true;
        } else {
            g_aimValid = false;
        }
    }
    if (g_viewValid && p_LocateSpace && g_aim2Space) {
        XrSpaceLocation loc{XR_TYPE_SPACE_LOCATION};
        if (p_LocateSpace(g_aim2Space, li->space, li->displayTime, &loc) == XR_SUCCESS &&
            (loc.locationFlags & XR_SPACE_LOCATION_POSITION_VALID_BIT) &&
            (loc.locationFlags & XR_SPACE_LOCATION_ORIENTATION_VALID_BIT)) {
            g_aim2Pose  = loc.pose;   // laser ray = position + qrot(orientation, -Z)
            g_aim2Valid = true;
        } else {
            g_aim2Valid = false;
        }
    }

    // Grab machine + per-eye panel projection (also emits the once/sec probe).
    update_panel();
    return r;
}

// ---- QUAD LAYER PATH -------------------------------------------------------
// Orthonormal basis (right, up, normal) -> quaternion. A quad layer is placed by
// a pose whose +Z is the face normal, +X right, +Y up, which is the basis
// update_panel() already maintains, so the panel's world placement and grab/carry
// behaviour apply unchanged.
static XrQuaternionf basis_to_quat(XrVector3f r, XrVector3f u, XrVector3f n) {
    const float m00 = r.x, m01 = u.x, m02 = n.x;
    const float m10 = r.y, m11 = u.y, m12 = n.y;
    const float m20 = r.z, m21 = u.z, m22 = n.z;
    const float tr = m00 + m11 + m22;
    XrQuaternionf q;
    if (tr > 0.f) {
        float s = sqrtf(tr + 1.f) * 2.f;
        q.w = 0.25f * s;
        q.x = (m21 - m12) / s; q.y = (m02 - m20) / s; q.z = (m10 - m01) / s;
    } else if (m00 > m11 && m00 > m22) {
        float s = sqrtf(1.f + m00 - m11 - m22) * 2.f;
        q.x = 0.25f * s;
        q.w = (m21 - m12) / s; q.y = (m01 + m10) / s; q.z = (m02 + m20) / s;
    } else if (m11 > m22) {
        float s = sqrtf(1.f + m11 - m00 - m22) * 2.f;
        q.y = 0.25f * s;
        q.w = (m02 - m20) / s; q.x = (m01 + m10) / s; q.z = (m12 + m21) / s;
    } else {
        float s = sqrtf(1.f + m22 - m00 - m11) * 2.f;
        q.z = 0.25f * s;
        q.w = (m10 - m01) / s; q.x = (m02 + m20) / s; q.y = (m12 + m21) / s;
    }
    float l = sqrtf(q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w);
    if (l > 1e-6f) { q.x/=l; q.y/=l; q.z/=l; q.w/=l; }
    else           { q = {0,0,0,1}; }
    return q;
}

// Render pass that CLEARs to transparent black. Render-pass compatibility in
// Vulkan ignores loadOp/storeOp/layouts, so ImGui's pipeline (created against
// g_renderPass, same format and subpass shape) is valid inside this one too.
static bool build_menu_pass() {
    VkAttachmentDescription color{};
    color.format         = g_eyeFormat;
    color.samples        = VK_SAMPLE_COUNT_1_BIT;
    color.loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR;
    color.storeOp        = VK_ATTACHMENT_STORE_OP_STORE;
    color.stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    color.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    color.initialLayout  = VK_IMAGE_LAYOUT_UNDEFINED;   // cleared, nothing to preserve
    color.finalLayout    = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkAttachmentReference ref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sub{};
    sub.pipelineBindPoint    = VK_PIPELINE_BIND_POINT_GRAPHICS;
    sub.colorAttachmentCount = 1;
    sub.pColorAttachments    = &ref;

    VkSubpassDependency dep{};
    dep.srcSubpass = VK_SUBPASS_EXTERNAL;
    dep.dstSubpass = 0;
    dep.srcStageMask  = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dep.dstStageMask  = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dep.srcAccessMask = 0;
    dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;

    VkRenderPassCreateInfo rp{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
    rp.attachmentCount = 1; rp.pAttachments  = &color;
    rp.subpassCount    = 1; rp.pSubpasses    = &sub;
    rp.dependencyCount = 1; rp.pDependencies = &dep;
    if (vkCreateRenderPass(g_vkDevice, &rp, nullptr, &g_menuPass) != VK_SUCCESS) {
        LOGE("[quad] vkCreateRenderPass failed"); return false;
    }
    return true;
}

// One-shot: create the swapchain, enumerate its images, build framebuffers, and
// bring ImGui up sized to OUR image count. Sets g_quadActive on success; on any
// failure leaves it false so hk_Release falls back to the eye-image path.
static void create_menu_swapchain() {
    // Prerequisites can arrive a few frames late. The app resolves XR entry points
    // through GIPA as it needs them, and xrWaitSwapchainImage in particular is
    // only fetched once it starts rendering. Retrying for ~2s avoids burning the
    // single attempt on frame 1 and silently demoting the whole menu to the
    // eye-image path. g_menuScTried stays false while retrying.
    static int attempts = 0;
    if (!g_haveVk || !g_xrSession || !o_CreateSwapchain || !o_Enum ||
        !o_Acquire || !o_Release || !o_Wait || g_eyeFormat == VK_FORMAT_UNDEFINED) {
        if (++attempts < 150) return;
        g_menuScTried = true;
        LOGE("[quad] prerequisites never arrived: vk=%d sess=%p create=%p enum=%p acq=%p rel=%p wait=%p fmt=%d",
             (int)g_haveVk, (void*)g_xrSession, (void*)o_CreateSwapchain, (void*)o_Enum,
             (void*)o_Acquire, (void*)o_Release, (void*)o_Wait, (int)g_eyeFormat);
        return;
    }
    g_menuScTried = true;

    float pw, ph; menu::panel_extent(pw, ph);
    g_menuW = (uint32_t)pw; g_menuH = (uint32_t)ph;

    // Reuse the game's eye format: the runtime is guaranteed to support it, and it
    // keeps colour handling (sRGB encode or not) identical to the eye-image path,
    // so the palette works the same on both.
    XrSwapchainCreateInfo ci{};
    ci.type        = XR_TYPE_SWAPCHAIN_CREATE_INFO;
    ci.usageFlags  = XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT | XR_SWAPCHAIN_USAGE_SAMPLED_BIT;
    ci.format      = (int64_t)g_eyeFormat;
    ci.sampleCount = 1;
    ci.width       = g_menuW;
    ci.height      = g_menuH;
    ci.faceCount   = 1;
    ci.arraySize   = 1;
    ci.mipCount    = 1;

    XrResult r = o_CreateSwapchain(g_xrSession, &ci, &g_menuSC);
    if (r != XR_SUCCESS || !g_menuSC) {
        LOGE("[quad] xrCreateSwapchain(%ux%u fmt=%d) -> %d", g_menuW, g_menuH, (int)g_eyeFormat, r);
        g_menuSC = nullptr; return;
    }

    uint32_t n = 0;
    if (o_Enum(g_menuSC, 0, &n, nullptr) != XR_SUCCESS || n == 0) {
        LOGE("[quad] image count query failed (n=%u)", n); g_menuSC = nullptr; return;
    }
    std::vector<XrSwapchainImageVulkanKHR> imgs(n);
    for (auto& i : imgs) { i.type = XR_TYPE_SWAPCHAIN_IMAGE_VULKAN_KHR; i.next = nullptr; }
    uint32_t got = 0;
    if (o_Enum(g_menuSC, n, &got, imgs.data()) != XR_SUCCESS || got != n) {
        LOGE("[quad] xrEnumerateSwapchainImages failed (got=%u of %u)", got, n);
        g_menuSC = nullptr; return;
    }
    g_menuImgs.resize(n);
    for (uint32_t i = 0; i < n; i++) g_menuImgs[i] = imgs[i].image;

    // ImGui must exist before framebuffers, because init_imgui builds the render
    // objects (descriptor/command pools) this path also uses.
    if (!g_imguiInited && !init_imgui(n)) { LOGE("[quad] init_imgui failed"); g_menuSC = nullptr; return; }
    if (!build_menu_pass()) { g_menuSC = nullptr; return; }

    g_menuViews.assign(n, VK_NULL_HANDLE);
    g_menuFbs.assign(n, VK_NULL_HANDLE);
    for (uint32_t i = 0; i < n; i++) {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image    = g_menuImgs[i];
        vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
        vi.format   = g_eyeFormat;
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        if (vkCreateImageView(g_vkDevice, &vi, nullptr, &g_menuViews[i]) != VK_SUCCESS) {
            LOGE("[quad] vkCreateImageView[%u] failed", i); g_menuSC = nullptr; return;
        }
        VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fi.renderPass = g_menuPass;
        fi.attachmentCount = 1; fi.pAttachments = &g_menuViews[i];
        fi.width = g_menuW; fi.height = g_menuH; fi.layers = 1;
        if (vkCreateFramebuffer(g_vkDevice, &fi, nullptr, &g_menuFbs[i]) != VK_SUCCESS) {
            LOGE("[quad] vkCreateFramebuffer[%u] failed", i); g_menuSC = nullptr; return;
        }
    }

    g_quadActive = true;
    LOGI("[quad] ACTIVE: swapchain %p %ux%u fmt=%d images=%u - eye-image compositing off",
         (void*)g_menuSC, g_menuW, g_menuH, (int)g_eyeFormat, n);
}

// Build one ImGui frame and rasterize it 1:1 into our swapchain. Returns true if
// there is something to composite this frame (false while faded out, so a closed
// menu costs no layer at all). Runs on the app's render thread from hk_EndFrame.
static bool render_menu_layer() {
    if (!g_quadActive || !g_menuSC || !g_projValid || !g_projSpace) return false;

    const float PW = (float)g_menuW, PH = (float)g_menuH;
    ImGuiIO& io    = ImGui::GetIO();
    io.DisplaySize = ImVec2(PW, PH);
    double t       = now_sec();
    io.DeltaTime   = (float)(t - g_lastTime);
    if (io.DeltaTime <= 0.0f || io.DeltaTime > 0.5f) io.DeltaTime = 1.0f / 72.0f;
    g_lastTime = t;

    // Input is read every frame even while closed: the thumbstick feeds
    // joystick-fly through features::, which must keep working with the menu
    // hidden. Only the pointer is parked when the panel isn't interactive.
    read_input(PW, PH, io.DeltaTime);
    bool interact   = g_cursorVis && g_panelVis && g_menuOpen;
    io.MousePos     = interact ? ImVec2(g_cursorX, g_cursorY) : ImVec2(-1e6f, -1e6f);
    io.MouseDown[0] = g_click && interact;
    io.MouseDrawCursor = interact;

    ImGui_ImplVulkan_NewFrame();
    ImGui::NewFrame();
    menu::render(g_menuOpen);          // owns its own open/close fade
    ImGui::Render();
    ImDrawData* dd = ImGui::GetDrawData();
    // Faded fully out (or hidden by the near-plane guard): nothing to submit.
    if (!dd || dd->TotalVtxCount == 0 || !g_panelVis) return false;

    // Swapchain image lifetime. Two rules matter here:
    //  - an acquired image that is never released is gone for good, and once all
    //    of them are gone the next acquire blocks or fails forever;
    //  - XR_TIMEOUT_EXPIRED is a SUCCESS code, and on it the image is still
    //    acquired and must NOT be released; the wait has to be retried. So a
    //    timeout keeps the image held and re-waits next frame instead of
    //    acquiring a second one.
    static bool     s_held    = false;
    static uint32_t s_heldIdx = 0;
    XrSwapchainImageReleaseInfo ri{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO, nullptr};
    if (!s_held) {
        uint32_t got = 0;
        if (o_Acquire(g_menuSC, nullptr, &got) != XR_SUCCESS) return false;
        s_held = true; s_heldIdx = got;
    }
    const uint32_t idx = s_heldIdx;
    if (idx >= g_menuFbs.size()) {          // unreachable: acquire returns < imageCount
        LOGE("[quad] acquire returned idx=%u for %zu framebuffers", idx, g_menuFbs.size());
        o_Release(g_menuSC, &ri); s_held = false;
        return false;
    }
    XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO, nullptr, 100000000};  // 100ms
    XrResult wr = o_Wait(g_menuSC, &wi);
    if (wr == XR_TIMEOUT_EXPIRED) return false;   // still ours; wait again next frame
    if (wr != XR_SUCCESS) { o_Release(g_menuSC, &ri); s_held = false; return false; }

    // 1:1, so ImGui's own clip rects survive and lists can clip and scroll. The
    // eye-image path has to override them to the full framebuffer instead.
    dd->DisplayPos       = ImVec2(0, 0);
    dd->DisplaySize      = ImVec2(PW, PH);
    dd->FramebufferScale = ImVec2(1, 1);

    vkResetCommandBuffer(g_cmd, 0);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(g_cmd, &bi);

    VkClearValue clear{};
    clear.color = {{0.f, 0.f, 0.f, 0.f}};       // transparent: the compositor blends it
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    rb.renderPass  = g_menuPass;
    rb.framebuffer = g_menuFbs[idx];
    rb.renderArea  = {{0, 0}, {g_menuW, g_menuH}};
    rb.clearValueCount = 1; rb.pClearValues = &clear;
    vkCmdBeginRenderPass(g_cmd, &rb, VK_SUBPASS_CONTENTS_INLINE);
    ImGui_ImplVulkan_RenderDrawData(dd, g_cmd);
    vkCmdEndRenderPass(g_cmd);
    vkEndCommandBuffer(g_cmd);

    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1; si.pCommandBuffers = &g_cmd;
    if (vkQueueSubmit(g_vkQueue, 1, &si, VK_NULL_HANDLE) == VK_SUCCESS) vkQueueWaitIdle(g_vkQueue);
    else LOGE("[quad] vkQueueSubmit failed");

    o_Release(g_menuSC, &ri);
    s_held = false;

    g_quadLayer = {};
    g_quadLayer.type          = XR_TYPE_COMPOSITION_LAYER_QUAD;
    g_quadLayer.layerFlags    = XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;
    g_quadLayer.space         = g_projSpace;   // same space g_quad.anchor lives in
    g_quadLayer.eyeVisibility = XR_EYE_VISIBILITY_BOTH;
    g_quadLayer.subImage.swapchain = g_menuSC;
    // Only the MAIN BAND of the canvas. The rows below it are the keyboard's and
    // are shown by the second layer at its own angle; leaving them in here would
    // draw the keyboard twice, once flat and once tilted.
    g_quadLayer.subImage.imageRect =
        {{0, 0}, {(int32_t)g_menuW, (int32_t)main_band_px()}};
    g_quadLayer.subImage.imageArrayIndex = 0;
    XrVector3f qRgt = g_quad.rgt, qNrm = g_quad.nrm;
    if (QUAD_FACE_FLIP) { qRgt = vscale(qRgt, -1.f); qNrm = vscale(qNrm, -1.f); }
    g_quadLayer.pose.position    = g_quad.anchor;
    g_quadLayer.pose.orientation = basis_to_quat(qRgt, g_quad.up, qNrm);
    g_quadLayer.size = {g_quad.halfW * 2.f, g_quad.halfH * 2.f};

    // ---- the keyboard's layer ----------------------------------------------
    // Same swapchain, same texture, same frame, only a different rect of it and a
    // different pose. A second SURFACE costs one more layer; it does not need a
    // second render target or a second draw pass.
    g_kbLayerReady = false;
    if (g_kbVisible && g_kbTilt3D) {
        float kx, ky, kw, kh; menu::keyboard_rect(kx, ky, kw, kh);
        g_kbLayer = {};
        g_kbLayer.type          = XR_TYPE_COMPOSITION_LAYER_QUAD;
        g_kbLayer.layerFlags    = XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;
        g_kbLayer.space         = g_projSpace;
        g_kbLayer.eyeVisibility = XR_EYE_VISIBILITY_BOTH;
        g_kbLayer.subImage.swapchain = g_menuSC;
        g_kbLayer.subImage.imageRect =
            {{(int32_t)kx, (int32_t)ky}, {(int32_t)kw, (int32_t)kh}};
        g_kbLayer.subImage.imageArrayIndex = 0;
        XrVector3f kRgt = g_kbQuad.rgt, kNrm = g_kbQuad.nrm;
        if (QUAD_FACE_FLIP) { kRgt = vscale(kRgt, -1.f); kNrm = vscale(kNrm, -1.f); }
        g_kbLayer.pose.position    = g_kbQuad.anchor;
        g_kbLayer.pose.orientation = basis_to_quat(kRgt, g_kbQuad.up, kNrm);
        g_kbLayer.size = {g_kbQuad.halfW * 2.f, g_kbQuad.halfH * 2.f};
        g_kbLayerReady = true;
    }

    static double s_log = -1e9;
    if (now_sec() - s_log > 15.0) {   // throttled: don't flush the log ring buffer
        s_log = now_sec();
        // facing = dot(quad normal, panel->head). Positive means the normal we
        // handed the runtime as +Z really does point at the viewer, so if the
        // panel is INVISIBLE while this is positive, the runtime's front-face
        // convention is the opposite of ours -> set QUAD_FACE_FLIP true.
        XrVector3f H = vscale(vadd(g_view[0].pose.position, g_view[1].pose.position), 0.5f);
        float facing = vdot(qNrm, vsub(H, g_quad.anchor));
        LOGI("[quad] img=%u pos=(%.2f,%.2f,%.2f) size=%.2fx%.2fm vtx=%d facing=%+.3f",
             idx, g_quadLayer.pose.position.x, g_quadLayer.pose.position.y,
             g_quadLayer.pose.position.z, g_quadLayer.size.width, g_quadLayer.size.height,
             dd->TotalVtxCount, facing);
    }
    return true;
}

// The app submits its finished eye images here. The projection layer is the
// authoritative source of which swapchain+array-layer is each eye and the exact
// render rectangle inside that swapchain (smaller than the swapchain under
// dynamic resolution). Cache it for render_overlay, then pass the call through.
static XrResult hk_EndFrame(XrSession s, const XrFrameEndInfo* fi) {
    if (fi && fi->layers && fi->layerCount) {
        ProjView found[2]{};
        XrSpace  layerSpace = nullptr;
        bool ok = false;
        for (uint32_t li = 0; li < fi->layerCount; li++) {
            const XrCompositionLayerBaseHeader* base = fi->layers[li];
            if (!base || base->type != XR_TYPE_COMPOSITION_LAYER_PROJECTION) continue;
            const auto* pj = (const XrCompositionLayerProjection*)base;
            if (!pj->views || pj->viewCount != 2) continue;   // Quest stereo only
            layerSpace = pj->space;
            for (uint32_t i = 0; i < 2; i++) {
                const XrCompositionLayerProjectionView& v = pj->views[i];
                found[i].swapchain  = v.subImage.swapchain;
                found[i].arrayIndex = v.subImage.imageArrayIndex;
                found[i].rectX = v.subImage.imageRect.offset.x;
                found[i].rectY = v.subImage.imageRect.offset.y;
                found[i].rectW = v.subImage.imageRect.extent.width;
                found[i].rectH = v.subImage.imageRect.extent.height;
                found[i].pose  = v.pose;
                found[i].fov   = v.fov;
                found[i].valid = v.subImage.swapchain != nullptr &&
                                 found[i].rectW > 0 && found[i].rectH > 0;
            }
            ok = found[0].valid && found[1].valid;
            break;   // first (primary) projection layer wins
        }
        if (ok) {
            std::lock_guard<std::mutex> lk(g_mtx);
            g_proj[0] = found[0];
            g_proj[1] = found[1];
            g_projValid = true;
            g_projSpace = layerSpace;
        }
    }
    // This frame is submitted: its view snapshot is spent, promote the next.
    if (fi && g_snapCur.valid && g_snapNext.valid && g_snapCur.t <= fi->displayTime) {
        g_snapCur = g_snapNext;
        g_snapNext.valid = false;
    }

    // ---- menu quad layer ----------------------------------------------------
    // Created on the first frame that has a projection layer, because that is
    // what tells us the space the panel pose must be expressed in. Appended
    // AFTER the app's layers so it composites on top of the world.
    g_xrSession = s;
    if (!g_menuScTried && g_projValid) create_menu_swapchain();

    g_quadReady = render_menu_layer();
    if (g_quadReady && fi && fi->layers && fi->layerCount) {
        std::vector<const XrCompositionLayerBaseHeader*> layers;
        layers.reserve(fi->layerCount + 2);
        for (uint32_t i = 0; i < fi->layerCount; i++) layers.push_back(fi->layers[i]);
        layers.push_back((const XrCompositionLayerBaseHeader*)&g_quadLayer);
        // After the windows, so where the two surfaces meet at the hinge the
        // keyboard wins; it is the nearer of the two by the width of the gap.
        if (g_kbLayerReady) layers.push_back((const XrCompositionLayerBaseHeader*)&g_kbLayer);

        XrFrameEndInfo m = *fi;
        m.layerCount = (uint32_t)layers.size();
        m.layers     = layers.data();
        XrResult r = o_EndFrame(s, &m);
        // Only NEGATIVE XrResults are failures; positive ones (XR_SESSION_LOSS_PENDING,
        // XR_FRAME_DISCARDED) are successes where the frame WAS consumed. Retrying
        // xrEndFrame after one of those would submit the same frame twice, which is
        // a call-order violation, so pass them straight through.
        if (r >= 0) return r;
        // Rejected. Before giving up the menu entirely, drop just the KEYBOARD
        // layer and try once more. It is the stranger of the two (a second quad,
        // off-axis, sharing one swapchain), so it is the likelier thing a runtime
        // objects to, and the menu should not go down with it.
        if (g_kbLayerReady) {
            LOGE("[quad] xrEndFrame rejected -> %d with the keyboard layer attached; "
                 "retrying without it", r);
            layers.pop_back();
            XrFrameEndInfo m2 = *fi;
            m2.layerCount = (uint32_t)layers.size();
            m2.layers     = layers.data();
            XrResult r2 = o_EndFrame(s, &m2);
            if (r2 >= 0) { g_kbTilt3D = false; return r2; }   // keep the menu, lose the tilt
            r = r2;
        }
        // A rejected layer must never cost the game its frames. Fall back for
        // good rather than failing (and double-submitting) every frame from here.
        LOGE("[quad] xrEndFrame rejected our layer -> %d; disabling the quad layer", r);
        g_quadActive = false;
        return o_EndFrame(s, fi);
    }
    return o_EndFrame(s, fi);
}

// Reads our menu actions and updates cursor/click/toggle. Called per frame from
// render_overlay (w/h/dt = current eye buffer size + frame delta).
static void read_input(float w, float h, float dt) {
    if (!g_inputReady || !g_xrSession) return;

    if (g_cursorX < 0) { g_cursorX = w * 0.5f; g_cursorY = h * 0.5f; }
    if (o_GetVec2 && g_aCursor) {
        XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO, nullptr, g_aCursor, XR_NULL_PATH};
        XrActionStateVector2f st{XR_TYPE_ACTION_STATE_VECTOR2F};
        if (o_GetVec2(g_xrSession, &gi, &st) == XR_SUCCESS && st.isActive) {
            float x = st.currentState.x, y = st.currentState.y;
            bool flyOn = features::flyEnabled.load();
            // When fly is ON the stick drives FLIGHT whether or not the menu is open,
            // and it does NOT move the cursor. When fly is OFF the menu owns the stick
            // (cursor) and fly reads 0. Zeroing the stick while the menu is open would
            // strand you: toggling fly on in the menu would then produce no motion.
            // Toggle fly off with the laser and trigger.
            features::stickX.store(flyOn ? x : (g_menuOpen ? 0.f : x));
            features::stickY.store(flyOn ? y : (g_menuOpen ? 0.f : y));
            static double s_stickLog = -1e9;
            if (now_sec() - s_stickLog > 15.0) {  // throttled, same reason as [esp]
                s_stickLog = now_sec();
                LOGI("[stick] raw=(%.2f,%.2f) active=%d menuOpen=%d flyOn=%d",
                     x, y, (int)st.isActive, (int)g_menuOpen, (int)flyOn);
            }
            if (!flyOn && x*x + y*y > 0.04f) {  // cursor nudge only when NOT flying
                float speed = w * 0.75f;      // px/sec at full deflection
                g_cursorX += x * speed * dt;
                g_cursorY -= y * speed * dt;  // stick up = cursor up
                g_stickTime = now_sec();      // keeps the cursor visible below
            }
        } else {
            features::stickX.store(0.f); features::stickY.store(0.f);
        }
    }
    // RIGHT stick: dedicated action. Y drives altitude while flying (push up =
    // rise) and, when NOT flying, scrolls the menu's lists.
    float rStickY = 0.f;
    if (o_GetVec2 && g_aCursorR) {
        XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO, nullptr, g_aCursorR, XR_NULL_PATH};
        XrActionStateVector2f st{XR_TYPE_ACTION_STATE_VECTOR2F};
        if (o_GetVec2(g_xrSession, &gi, &st) == XR_SUCCESS && st.isActive) {
            rStickY = st.currentState.y;
            features::stickUp.store(features::flyEnabled.load() ? rStickY : 0.f);
        } else {
            features::stickUp.store(0.f);
        }
    }
    // RIGHT trigger as an analog throttle for slingshot fly. Read on its own
    // action so it does not disturb g_aClick, which still owns menu clicking off
    // whichever trigger you pull.
    if (o_GetFloat && g_aTrigR) {
        XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO, nullptr, g_aTrigR, XR_NULL_PATH};
        XrActionStateFloat st{XR_TYPE_ACTION_STATE_FLOAT};
        if (o_GetFloat(g_xrSession, &gi, &st) == XR_SUCCESS && st.isActive)
            features::triggerR.store(st.currentState);
        else
            features::triggerR.store(0.f);
    }

    // RIGHT grip. Drives both spawn modes: held it repeats a spawn into your hand,
    // or shows the spawn-gun laser. Its own action for the same reason as the
    // trigger above: one action bound to both hands gets collapsed by the runtime.
    if (o_GetFloat && g_aGripR) {
        XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO, nullptr, g_aGripR, XR_NULL_PATH};
        XrActionStateFloat st{XR_TYPE_ACTION_STATE_FLOAT};
        if (o_GetFloat(g_xrSession, &gi, &st) == XR_SUCCESS && st.isActive)
            features::gripR.store(st.currentState);
        else
            features::gripR.store(0.f);
    }

    // GUI scrolling is deliberately not bound to either joystick. In-headset
    // scrolling is controlled only by clicking or dragging the visible far-right
    // scrollbar, so normal stick movement cannot shift the menu by accident.
    ImGui::GetIO().MouseWheel = 0.f;
    // Laser wins while the aim ray is on a surface. The ray-cast already resolved
    // WHICH surface and mapped the hit into canvas pixels, so there is nothing
    // left to remap here: the tilted keyboard and the upright windows arrive in
    // the same coordinate space and are indistinguishable by this point.
    if (g_rayOnPanel) {
        g_cursorX = g_rayPxX;
        g_cursorY = g_rayPxY;
    }
    g_cursorVis = g_rayOnPanel || (now_sec() - g_stickTime) < 2.0;
    if (g_cursorX < 0.f) g_cursorX = 0.f; else if (g_cursorX > w) g_cursorX = w;
    if (g_cursorY < 0.f) g_cursorY = 0.f; else if (g_cursorY > h) g_cursorY = h;

    if (o_GetFloat && g_aClick) {
        XrActionStateGetInfo gi{XR_TYPE_ACTION_STATE_GET_INFO, nullptr, g_aClick, XR_NULL_PATH};
        XrActionStateFloat st{XR_TYPE_ACTION_STATE_FLOAT};
        if (o_GetFloat(g_xrSession, &gi, &st) == XR_SUCCESS && st.isActive)
            g_click = st.currentState > 0.6f;
    }
}

// ---- xrGetInstanceProcAddr interception ------------------------------------
// The Meta loader returns per-instance dispatch pointers from GIPA that are
// NOT the exported symbols, so we must wrap the pointers it hands back rather
// than patch the exports. This is what Nexus does ("Hooked xrCreateSession
// via xrGetInstanceProcAddr").
static XrResult hk_GIPA(XrInstance inst, const char* name, PFN_xrVoid* fn) {
    XrResult r = o_GIPA(inst, name, fn);
    if (r != XR_SUCCESS || !name || !fn || !*fn) return r;

#define WRAP(sym, store, hookfn)                                   \
    do { if (strcmp(name, sym) == 0) {                             \
        store = (decltype(store))*fn;                              \
        *fn   = (PFN_xrVoid)hookfn;                                \
        LOGI("wrapped %s", sym);                                   \
        return r; } } while (0)

// Capture the pointer without installing a wrapper; these are only called by
// us, never intercepted.
#define CAPTURE(sym, store)                                        \
    do { if (strcmp(name, sym) == 0) {                             \
        store = (decltype(store))*fn;                              \
        return r; } } while (0)

    WRAP("xrCreateSession",            o_CreateSession,    hk_CreateSession);
    WRAP("xrCreateSwapchain",          o_CreateSwapchain,  hk_CreateSwapchain);
    WRAP("xrDestroySwapchain",         o_DestroySwapchain, hk_DestroySwapchain);
    WRAP("xrEnumerateSwapchainImages", o_Enum,             hk_Enum);
    WRAP("xrAcquireSwapchainImage",    o_Acquire,          hk_Acquire);
    WRAP("xrReleaseSwapchainImage",    o_Release,          hk_Release);
    CAPTURE("xrWaitSwapchainImage",     o_Wait);
    CAPTURE("xrCreateAction",           o_CreateAction);
    CAPTURE("xrGetActionStateFloat",    o_GetFloat);
    CAPTURE("xrGetActionStateBoolean",  o_GetBool);
    CAPTURE("xrGetActionStateVector2f", o_GetVec2);
    WRAP("xrSuggestInteractionProfileBindings", o_Suggest, hk_Suggest);
    WRAP("xrAttachSessionActionSets",  o_Attach,           hk_Attach);
    WRAP("xrSyncActions",              o_Sync,             hk_Sync);
    WRAP("xrLocateViews",              o_LocateViews,      hk_LocateViews);
    WRAP("xrEndFrame",                 o_EndFrame,         hk_EndFrame);
#undef WRAP
#undef CAPTURE
    return r;
}

// Follow an AArch64 `B` thunk to the function it tail-calls; else return p.
static void* follow_b(void* p) {
    uint32_t insn = *(uint32_t*)p;
    if ((insn >> 26) == 0x05) { // unconditional B
        int32_t imm = insn & 0x03FFFFFF;
        if (imm & 0x02000000) imm |= 0xFC000000; // sign-extend 26 bits
        return (void*)((uintptr_t)p + ((int64_t)imm << 2));
    }
    return p;
}

// ---- install ---------------------------------------------------------------
namespace xr_hook {

bool init() {
    void* h = dlopen("libopenxr_loader.so", RTLD_NOW | RTLD_NOLOAD);
    if (!h) h = dlopen("libopenxr_loader.so", RTLD_NOW);

    void* gipaExport = h ? dlsym(h, "xrGetInstanceProcAddr") : nullptr;
    if (!gipaExport) gipaExport = elfutil::find_export("libopenxr_loader.so", "xrGetInstanceProcAddr");
    if (!gipaExport) { LOGE("could not resolve xrGetInstanceProcAddr"); return false; }

    // The export is a 4-byte `B` thunk into the real implementation; hook that.
    void* realGipa = follow_b(gipaExport);
    LOGI("GIPA export=%p real=%p", gipaExport, realGipa);

    bool ok = inlinehook::hook(realGipa, (void*)hk_GIPA, (void**)&o_GIPA);
    if (ok) LOGI("inline hook on real xrGetInstanceProcAddr installed");
    else    LOGE("GIPA inline hook failed");
    return ok;
}

void set_menu_open(bool open) { g_menuOpen = open; }
bool menu_open()              { return g_menuOpen; }
void toggle_menu()            { g_menuOpen = !g_menuOpen; }

void inject_pointer(float x, float y, bool down) {
    if (!g_imguiInited) return;
    ImGuiIO& io     = ImGui::GetIO();
    io.MousePos     = ImVec2(x, y);
    io.MouseDown[0] = down;
}

} // namespace xr_hook
