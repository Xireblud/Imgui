/* Komi — runnable demo (v0.2, card + accordion design).

   Build with a Dear ImGui checkout beside this folder:

   g++ -std=c++17 komi_demo.cpp komi_theme.cpp
       ../imgui/imgui.cpp ../imgui/imgui_draw.cpp ../imgui/imgui_tables.cpp
       ../imgui/imgui_widgets.cpp ../imgui/backends/imgui_impl_glfw.cpp
       ../imgui/backends/imgui_impl_opengl3.cpp
       -I../imgui -I../imgui/backends
       $(pkg-config --cflags --libs glfw3) -lGL -ldl -o komi_demo
*/

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include "komi_theme.h"

#include <GLFW/glfw3.h>
#include <cstdio>

namespace {

int  g_tab = 1;
bool g_open[8] = { true, false, false, false, false, false, false, false };
bool g_bookmarked[8] = { false, false, false, false, false, false, false, false };

struct Category {
    const char* name;
    int count;
    const char* items[4];
    int item_count;
};

const Category kCategories[] = {
    { "Layouts",     4, { "Default Window", "Compact Dock", "Pin Side Panel", "Reset Layout" }, 4 },
    { "Shortcuts",   6, { nullptr, nullptr, nullptr, nullptr }, 0 },
    { "Panels",     10, { nullptr, nullptr, nullptr, nullptr }, 0 },
    { "Appearance",  9, { nullptr, nullptr, nullptr, nullptr }, 0 },
    { "Diagnostics",12, { nullptr, nullptr, nullptr, nullptr }, 0 },
    { "Workspaces",  8, { nullptr, nullptr, nullptr, nullptr }, 0 },
    { "Plugins",     5, { nullptr, nullptr, nullptr, nullptr }, 0 },
};

const char* kTabs[] = {
    "Favorites", "Presets", "Widget Gallery", "Settings", "Logs", "Credits", "Enabled"
};

void DrawKomiUI()
{
    const ImGuiIO& io = ImGui::GetIO();
    const ImVec2 d = io.DisplaySize;
    komi::Page(d);

    // Card sits centred with a small top margin, like the reference.
    const float card_w = d.x * 0.835f;
    const float card_h = d.y * 0.815f;
    const ImVec2 card_pos((d.x - card_w) * 0.5f, d.y * 0.075f);
    komi::CardBackground(card_pos, ImVec2(card_w, card_h));

    ImGui::SetNextWindowPos(card_pos);
    ImGui::SetNextWindowSize(ImVec2(card_w, card_h));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
    ImGui::SetNextWindowBgAlpha(0.0f);
    ImGui::Begin("##komi_card", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                 ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus |
                 ImGuiWindowFlags_NoScrollbar);
    ImGui::PopStyleVar();

    komi::Header("Komi", "v3.55", card_pos, card_w, "komi.dev/community");

    g_tab = komi::TabBar(ImVec2(card_pos.x, card_pos.y + komi::kHeaderHeight),
                         card_w, kTabs, IM_ARRAYSIZE(kTabs), g_tab);

    // list area
    const float list_y = card_pos.y + komi::kHeaderHeight + komi::kTabHeight;
    ImGui::SetCursorScreenPos(ImVec2(card_pos.x + 20.0f, list_y));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.0f, 8.0f));
    ImGui::BeginChild("##komi_list", ImVec2(card_w - 40.0f, card_h - (list_y - card_pos.y) - 20.0f),
                      false, ImGuiWindowFlags_NoBringToFrontOnFocus);

    const int cat_count = IM_ARRAYSIZE(kCategories);
    for (int i = 0; i < cat_count; ++i) {
        const Category& cat = kCategories[i];
        if (komi::CategoryRow(cat.name, cat.count, g_open[i]) && cat.item_count > 0)
            g_open[i] = !g_open[i];

        if (!g_open[i] || cat.item_count == 0) continue;

        // nested block, indented like the reference
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.0f, 0.0f));
        ImGui::Dummy(ImVec2(0.0f, 0.0f));
        ImGui::Indent(32.0f);
        for (int k = 0; k < cat.item_count; ++k) {
            const komi::ItemHits hits = komi::ItemRow(
                cat.items[k], g_bookmarked[i], k == 0, k == cat.item_count - 1);
            if (hits.bookmark) g_bookmarked[i] = !g_bookmarked[i];
        }
        ImGui::Unindent(32.0f);
        ImGui::PopStyleVar();
    }

    ImGui::EndChild();
    ImGui::PopStyleVar(2);

    komi::ResizeGrip(ImVec2(card_pos.x + card_w - 26.0f, card_pos.y + card_h - 26.0f));

    ImGui::End();
}

void OnGlfwError(int code, const char* message)
{
    std::fprintf(stderr, "GLFW error %d: %s\n", code, message);
}

} // namespace

int main()
{
    glfwSetErrorCallback(OnGlfwError);
    if (!glfwInit()) return 1;

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(1568, 1040, "Komi", nullptr, nullptr);
    if (!window) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = nullptr;
    ImGui::StyleColorsDark();
    komi::ApplyTheme(1.0f);

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 150");

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        DrawKomiUI();

        ImGui::Render();

        int fb_w = 0, fb_h = 0;
        glfwGetFramebufferSize(window, &fb_w, &fb_h);
        glViewport(0, 0, fb_w, fb_h);
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
