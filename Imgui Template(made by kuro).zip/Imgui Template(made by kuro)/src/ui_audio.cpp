#include "ui_audio.h"

#include <aaudio/AAudio.h>

#include <atomic>
#include <cmath>
#include <cstdint>

namespace ui_audio {
namespace {

constexpr float kPi = 3.14159265358979323846f;
std::atomic<int> g_pending {-1};
std::atomic<bool> g_enabled {true};
AAudioStream* g_stream = nullptr;
int g_active = -1;
int g_sample = 0;
uint32_t g_noise = 0xA341316Cu;

float noise_sample() {
    g_noise ^= g_noise << 13;
    g_noise ^= g_noise >> 17;
    g_noise ^= g_noise << 5;
    return (float)(g_noise & 0xffffu) / 32767.5f - 1.f;
}

float tone(float hz, float seconds, float gain, int rate) {
    const float t = (float)g_sample / (float)rate;
    if (t >= seconds) return 0.f;
    const float env = (1.f - t / seconds);
    return sinf(2.f * kPi * hz * t) * env * env * gain;
}

float render_sample(int rate) {
    const float t = (float)g_sample / (float)rate;
    float out = 0.f;
    switch ((Cue)g_active) {
        case Cue::Open:
            // Two quiet midrange taps, closer to a compact latch than a startup
            // chime. There is deliberately no frequency below 400 Hz.
            out = tone(480.f, 0.045f, 0.040f, rate);
            if (t > 0.048f) {
                const float local = t - 0.048f;
                const float env = local < 0.050f ? 1.f - local / 0.050f : 0.f;
                out += sinf(2.f * kPi * 640.f * local) * env * env * 0.032f;
            }
            out += noise_sample() * (t < 0.007f ? (1.f - t / 0.007f) * 0.010f : 0.f);
            break;
        case Cue::Close:
            if (t < 0.060f) {
                const float hz = 560.f - 150.f * (t / 0.060f);
                const float env = 1.f - t / 0.060f;
                out = sinf(2.f * kPi * hz * t) * env * env * 0.034f;
            }
            out += noise_sample() * (t < 0.006f ? (1.f - t / 0.006f) * 0.008f : 0.f);
            break;
        case Cue::Hover:
            out = tone(1040.f, 0.016f, 0.018f, rate);
            out += noise_sample() * (t < 0.005f ? (1.f - t / 0.005f) * 0.006f : 0.f);
            break;
        case Cue::Select:
            out = tone(430.f, 0.032f, 0.036f, rate) + tone(860.f, 0.020f, 0.018f, rate);
            out += noise_sample() * (t < 0.007f ? (1.f - t / 0.007f) * 0.010f : 0.f);
            break;
    }
    ++g_sample;
    return out * 0.72f;
}

aaudio_data_callback_result_t audio_callback(AAudioStream* stream, void*, void* data,
                                              int32_t frames) {
    const int pending = g_pending.exchange(-1, std::memory_order_acq_rel);
    if (pending >= 0) {
        g_active = pending;
        g_sample = 0;
    }
    const int channels = AAudioStream_getChannelCount(stream);
    const int rate = AAudioStream_getSampleRate(stream);
    float* output = static_cast<float*>(data);
    for (int32_t frame = 0; frame < frames; ++frame) {
        const float sample = g_active >= 0 ? render_sample(rate) : 0.f;
        for (int channel = 0; channel < channels; ++channel)
            output[frame * channels + channel] = sample;
        if (g_sample > rate / 4) g_active = -1;
    }
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

bool ensure_stream() {
    if (g_stream) return true;
    AAudioStreamBuilder* builder = nullptr;
    if (AAudio_createStreamBuilder(&builder) != AAUDIO_OK || !builder) return false;
    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setChannelCount(builder, 2);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setDataCallback(builder, audio_callback, nullptr);
    const aaudio_result_t opened = AAudioStreamBuilder_openStream(builder, &g_stream);
    AAudioStreamBuilder_delete(builder);
    if (opened != AAUDIO_OK || !g_stream) {
        g_stream = nullptr;
        return false;
    }
    if (AAudioStream_requestStart(g_stream) != AAUDIO_OK) {
        AAudioStream_close(g_stream);
        g_stream = nullptr;
        return false;
    }
    return true;
}

} // namespace

void play(Cue cue) {
    if (!g_enabled.load(std::memory_order_relaxed)) return;
    if (!ensure_stream()) return;
    g_pending.store((int)cue, std::memory_order_release);
}

bool enabled() { return g_enabled.load(std::memory_order_relaxed); }

void set_enabled(bool enabled) {
    g_enabled.store(enabled, std::memory_order_relaxed);
    if (!enabled) g_pending.store(-1, std::memory_order_relaxed);
}

void shutdown() {
    if (!g_stream) return;
    AAudioStream_requestStop(g_stream);
    AAudioStream_close(g_stream);
    g_stream = nullptr;
}

} // namespace ui_audio
