#include "komi_theme.h"

#include <cmath>
#include <cstdio>
#include <vector>

namespace komi {

namespace {

float g_s = 1.0f; // ui scale, set by ApplyTheme()

constexpr float kPi = 3.14159265358979f;

template <typename T>
T Clamp(T v, T lo, T hi) { return (v < lo) ? lo : ((v > hi) ? hi : v); }


ImVec2 ScaledTextSize(const char* text, float size)
{
    ImVec2 ts = ImGui::CalcTextSize(text);
    const float base = ImGui::GetFontSize();
    if (base > 0.0f) {
        const float k = size / base;
        ts.x *= k;
        ts.y *= k;
    }
    return ts;
}

void TextAt(ImDrawList* dl, ImVec2 pos, ImU32 col, const char* text, float size)
{
    dl->AddText(ImGui::GetFont(), size, pos, col, text);
}

// Vertically centred text inside a box, left aligned at pad_x or centred.
void TextInBox(ImDrawList* dl, ImVec2 box_min, ImVec2 box_size, ImU32 col,
               const char* text, float size, float pad_x, bool centred)
{
    const ImVec2 ts = ScaledTextSize(text, size);
    ImVec2 p = box_min;
    p.y += (box_size.y - ts.y) * 0.5f;
    p.x += centred ? (box_size.x - ts.x) * 0.5f : pad_x;
    dl->AddText(ImGui::GetFont(), size, p, col, text);
}

// ---------------------------------------------------------------- icons
void IconBookmark(ImDrawList* dl, ImVec2 c, float r, ImU32 col, float th)
{
    ImVec2 pts[5] = {
        ImVec2(c.x - r * 0.62f, c.y - r * 0.92f),
        ImVec2(c.x + r * 0.62f, c.y - r * 0.92f),
        ImVec2(c.x + r * 0.62f, c.y + r * 0.92f),
        ImVec2(c.x,              c.y + r * 0.30f),
        ImVec2(c.x - r * 0.62f, c.y + r * 0.92f),
    };
    dl->AddPolyline(pts, 5, col, ImDrawFlags_Closed, th);
}

void IconMail(ImDrawList* dl, ImVec2 c, float r, ImU32 col, float th)
{
    const float hw = r * 0.95f, hh = r * 0.72f;
    dl->AddRect(ImVec2(c.x - hw, c.y - hh), ImVec2(c.x + hw, c.y + hh), col, 2.5f * g_s, 0, th);
    dl->AddLine(ImVec2(c.x - hw, c.y - hh * 0.6f), ImVec2(c.x, c.y + hh * 0.15f), col, th);
    dl->AddLine(ImVec2(c.x, c.y + hh * 0.15f), ImVec2(c.x + hw, c.y - hh * 0.6f), col, th);
}

void IconPanel(ImDrawList* dl, ImVec2 c, float r, ImU32 col, float th)
{
    const float hw = r * 0.95f, hh = r * 0.82f;
    dl->AddRect(ImVec2(c.x - hw, c.y - hh), ImVec2(c.x + hw, c.y + hh), col, 2.5f * g_s, 0, th);
    dl->AddLine(ImVec2(c.x - hw * 0.55f, c.y - hh * 0.35f), ImVec2(c.x + hw * 0.2f, c.y - hh * 0.35f), col, th);
    dl->AddLine(ImVec2(c.x - hw * 0.55f, c.y + hh * 0.1f), ImVec2(c.x + hw * 0.55f, c.y + hh * 0.1f), col, th);
    dl->AddLine(ImVec2(c.x - hw * 0.55f, c.y + hh * 0.55f), ImVec2(c.x + hw * 0.1f, c.y + hh * 0.55f), col, th);
}

void IconGear(ImDrawList* dl, ImVec2 c, float r, ImU32 col, float th)
{
    dl->AddCircle(c, r * 0.42f, col, 0, th);
    dl->AddCircle(c, r * 0.86f, col, 0, th * 0.9f);
    for (int i = 0; i < 8; ++i) {
        const float a = (float)i * kPi * 0.25f;
        const ImVec2 p0(c.x + std::cos(a) * r * 0.86f, c.y + std::sin(a) * r * 0.86f);
        const ImVec2 p1(c.x + std::cos(a) * r * 1.05f, c.y + std::sin(a) * r * 1.05f);
        dl->AddLine(p0, p1, col, th);
    }
}

void IconChevron(ImDrawList* dl, ImVec2 c, float r, ImU32 col, float th, bool down)
{
    if (down) {
        dl->AddLine(ImVec2(c.x - r * 0.55f, c.y - r * 0.25f), ImVec2(c.x, c.y + r * 0.3f), col, th);
        dl->AddLine(ImVec2(c.x, c.y + r * 0.3f), ImVec2(c.x + r * 0.55f, c.y - r * 0.25f), col, th);
    } else {
        dl->AddLine(ImVec2(c.x - r * 0.25f, c.y - r * 0.55f), ImVec2(c.x + r * 0.3f, c.y), col, th);
        dl->AddLine(ImVec2(c.x + r * 0.3f, c.y), ImVec2(c.x - r * 0.25f, c.y + r * 0.55f), col, th);
    }
}

bool HitBox(const char* id, ImVec2 min, ImVec2 size)
{
    ImGui::SetCursorScreenPos(min);
    ImGui::PushID(id);
    const bool clicked = ImGui::InvisibleButton("##hit", size);
    ImGui::PopID();
    return clicked;
}

} // namespace

void ApplyTheme(float ui_scale)
{
    g_s = (ui_scale > 0.0f) ? ui_scale : 1.0f;

    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding   = kCardRounding * g_s;
    st.ChildRounding    = kRowRounding * g_s;
    st.PopupRounding    = kRowRounding * g_s;
    st.FrameRounding    = 8.0f * g_s;
    st.GrabRounding     = 4.0f * g_s;
    st.WindowPadding    = ImVec2(20.0f * g_s, 20.0f * g_s);
    st.FramePadding     = ImVec2(10.0f * g_s, 6.0f * g_s);
    st.ItemSpacing      = ImVec2(12.0f * g_s, 12.0f * g_s);
    st.ItemInnerSpacing = ImVec2(10.0f * g_s, 8.0f * g_s);
    st.ScrollbarSize    = 8.0f * g_s;
    st.WindowBorderSize = 0.0f;
    st.ChildBorderSize  = 0.0f;
    st.FrameBorderSize  = 0.0f;
    st.AntiAliasedLines = true;
    st.AntiAliasedFill  = true;

    ImVec4* c = st.Colors;
    c[ImGuiCol_Text]                 = ImVec4(0.96f, 0.96f, 0.96f, 1.00f);
    c[ImGuiCol_TextDisabled]         = ImVec4(0.66f, 0.66f, 0.66f, 1.00f);
    c[ImGuiCol_WindowBg]             = ImVec4(0.047f, 0.047f, 0.047f, 1.00f);
    c[ImGuiCol_ChildBg]              = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    c[ImGuiCol_PopupBg]              = ImVec4(0.09f, 0.09f, 0.09f, 1.00f);
    c[ImGuiCol_Border]               = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    c[ImGuiCol_Separator]            = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
    c[ImGuiCol_FrameBg]              = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    c[ImGuiCol_FrameBgHovered]       = ImVec4(1.00f, 1.00f, 1.00f, 0.04f);
    c[ImGuiCol_FrameBgActive]        = ImVec4(1.00f, 1.00f, 1.00f, 0.07f);
    c[ImGuiCol_ScrollbarBg]          = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    c[ImGuiCol_ScrollbarGrab]        = ImVec4(0.24f, 0.24f, 0.24f, 1.00f);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.33f, 0.33f, 0.33f, 1.00f);
    c[ImGuiCol_CheckMark]            = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    c[ImGuiCol_TextSelectedBg]       = ImVec4(0.35f, 0.40f, 0.95f, 0.45f);
}

void Page(ImVec2 display_size)
{
    ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0.0f, 0.0f), display_size, kPage);
}

void CardBackground(ImVec2 pos, ImVec2 size)
{
    ImGui::GetBackgroundDrawList()->AddRectFilled(
        pos, ImVec2(pos.x + size.x, pos.y + size.y), kCard, kCardRounding * g_s);
}

HeaderHits Header(const char* title, const char* version,
                  ImVec2 pos, float width, const char* action_label)
{
    const float s = g_s;
    HeaderHits hits;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float h = kHeaderHeight * s;

    // avatar
    const float av = 64.0f * s;
    const ImVec2 av_min(pos.x + 20.0f * s, pos.y + (h - av) * 0.5f);
    dl->AddRectFilledMultiColor(av_min, ImVec2(av_min.x + av, av_min.y + av),
                                kAvatarA, kAvatarB, kAvatarB, kAvatarA);
    dl->AddRect(av_min, ImVec2(av_min.x + av, av_min.y + av), kCard, 12.0f * s, 0, 1.0f * s);
    const char* initial = "K";
    const ImVec2 is = ScaledTextSize(initial, 23.0f * s);
    TextAt(dl, ImVec2(av_min.x + (av - is.x) * 0.5f, av_min.y + (av - is.y) * 0.5f), kText, initial, 23.0f * s);

    // title + chevron + version
    const ImVec2 ts = ScaledTextSize(title, 26.0f * s);
    const float tx = av_min.x + av + 20.0f * s;
    const float ty = pos.y + (h - ts.y) * 0.5f;
    TextAt(dl, ImVec2(tx, ty), kText, title, 26.0f * s);

    const ImVec2 cc(tx + ts.x + 18.0f * s, pos.y + h * 0.5f);
    IconChevron(dl, cc, 9.0f * s, kText, 2.2f * s, true);

    const char* ver = version ? version : "";
    TextInBox(dl, ImVec2(cc.x + 14.0f * s, pos.y), ImVec2(140.0f * s, h), kTextDim, ver, 14.0f * s, 0.0f, false);

    // accent action button, right aligned
    const float btn_h = 44.0f * s;
    const ImVec2 ab_min(pos.x + width - 20.0f * s - 200.0f * s, pos.y + (h - btn_h) * 0.5f);
    const ImVec2 ab_size(200.0f * s, btn_h);
    dl->AddRectFilled(ab_min, ImVec2(ab_min.x + ab_size.x, ab_min.y + ab_size.y), kAccent, 10.0f * s);
    TextInBox(dl, ab_min, ab_size, kText, action_label ? action_label : "", 16.0f * s, 22.0f * s, false);
    if (HitBox("cta", ab_min, ab_size)) hits.action = true;

    // icon buttons, to the left of the accent button
    const float icon_gap = 54.0f * s;
    const float icon_box = 34.0f * s;
    float ix = ab_min.x - 30.0f * s - icon_box;
    const float iy = pos.y + (h - icon_box) * 0.5f;

    struct Slot { const char* id; int kind; bool* flag; };
    Slot slots[4] = {
        { "icon_bookmark", 0, &hits.bookmark },
        { "icon_mail",     1, &hits.mail },
        { "icon_panel",    2, &hits.panel },
        { "icon_gear",     3, &hits.gear },
    };

    for (int k = 3; k >= 0; --k) {
        const ImVec2 b_min(ix, iy);
        if (HitBox(slots[k].id, b_min, ImVec2(icon_box, icon_box))) *slots[k].flag = true;

        const ImVec2 c(b_min.x + icon_box * 0.5f, b_min.y + icon_box * 0.5f);
        const float r = 11.0f * s;
        const float th = 1.9f * s;
        if (ImGui::IsItemHovered()) dl->AddCircleFilled(c, icon_box * 0.5f, IM_COL32(255, 255, 255, 12));
        switch (slots[k].kind) {
            case 0: IconBookmark(dl, c, r, kIcon, th); break;
            case 1: IconMail(dl, c, r, kIcon, th); break;
            case 2: IconPanel(dl, c, r, kIcon, th); break;
            default: IconGear(dl, c, r, kIcon, th); break;
        }
        ix -= (icon_box + (icon_gap - icon_box));
    }

    return hits;
}

int TabBar(ImVec2 pos, float width, const char* const* tabs, int count, int selected)
{
    const float s = g_s;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float h = kTabHeight * s;

    dl->AddLine(ImVec2(pos.x, pos.y), ImVec2(pos.x + width, pos.y), kHairline, 1.0f * s);

    std::vector<float> tab_w((size_t)count);
    float total = 0.0f;
    for (int i = 0; i < count; ++i) {
        tab_w[(size_t)i] = ScaledTextSize(tabs[i], 17.0f * s).x + 52.0f * s;
        total += tab_w[(size_t)i];
    }
    const float pad = 14.0f * s;
    const float gap = (count > 1) ? (width - total - pad * 2.0f) / (float)(count - 1) : 0.0f;

    float x = pos.x + pad;
    int result = selected;
    for (int i = 0; i < count; ++i) {
        const ImVec2 t_min(x, pos.y + (h - 48.0f * s) * 0.5f);
        const ImVec2 t_size(tab_w[(size_t)i], 48.0f * s);

        if (i == selected)
            dl->AddRectFilled(t_min, ImVec2(t_min.x + t_size.x, t_min.y + t_size.y), kPill, 10.0f * s);

        TextInBox(dl, t_min, t_size, kText, tabs[i], 17.0f * s, 0.0f, true);

        char id[32];
        std::snprintf(id, sizeof(id), "tab%d", i);
        if (HitBox(id, t_min, t_size)) result = i;
        if (ImGui::IsItemHovered()) ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);

        x += t_size.x + gap;
    }
    return result;
}

bool CategoryRow(const char* label, int count, bool open)
{
    const float s = g_s;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    const float h = kCatHeight * s;

    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), kRowBg, kRowRounding * s);
    dl->AddRect(p, ImVec2(p.x + w, p.y + h), kRowBorder, kRowRounding * s, 0, 1.0f * s);

    IconChevron(dl, ImVec2(p.x + 36.0f * s, p.y + h * 0.5f), 10.0f * s, kText, 2.6f * s, open);

    TextInBox(dl, p, ImVec2(w, h), kText, label, 19.0f * s, 62.0f * s, false);

    char buf[16];
    std::snprintf(buf, sizeof(buf), "%d", count);
    const ImVec2 cs = ScaledTextSize(buf, 18.0f * s);
    TextAt(dl, ImVec2(p.x + w - 26.0f * s - cs.x, p.y + (h - cs.y) * 0.5f), kText, buf, 18.0f * s);

    const bool clicked = HitBox(label, p, ImVec2(w, h));
    if (ImGui::IsItemHovered()) ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);

    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + h - 1.0f * s));
    return clicked;
}

ItemHits ItemRow(const char* label, bool bookmarked, bool first, bool last)
{
    const float s = g_s;
    ItemHits hits;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    const float h = kKidHeight * s;

    const ImDrawFlags corner = last ? ImDrawFlags_RoundCornersBottom : ImDrawFlags_RoundCornersNone;
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), kKidBg, kRowRounding * s, corner);
    dl->AddRect(p, ImVec2(p.x + w, p.y + h), kKidLine, kRowRounding * s, corner, 1.0f * s);
    if (!first)
        dl->AddLine(ImVec2(p.x, p.y), ImVec2(p.x + w, p.y), kKidLine, 1.0f * s);

    TextInBox(dl, p, ImVec2(w, h), kText, label, 18.5f * s, 26.0f * s, false);

    const float icon_box = 34.0f * s;
    const float iy = p.y + (h - icon_box) * 0.5f;
    const float gear_x = p.x + w - 20.0f * s - icon_box;
    const float book_x = gear_x - 26.0f * s - icon_box;

    // options (gear)
    if (HitBox("opt", ImVec2(gear_x, iy), ImVec2(icon_box, icon_box))) hits.options = true;
    {
        const ImVec2 c(gear_x + icon_box * 0.5f, iy + icon_box * 0.5f);
        if (ImGui::IsItemHovered()) dl->AddCircleFilled(c, icon_box * 0.5f, IM_COL32(255, 255, 255, 12));
        IconGear(dl, c, 11.0f * s, kIcon, 1.9f * s);
    }
    // bookmark
    if (HitBox("bm", ImVec2(book_x, iy), ImVec2(icon_box, icon_box))) hits.bookmark = true;
    {
        const ImVec2 c(book_x + icon_box * 0.5f, iy + icon_box * 0.5f);
        if (ImGui::IsItemHovered()) dl->AddCircleFilled(c, icon_box * 0.5f, IM_COL32(255, 255, 255, 12));
        if (bookmarked) {
            // filled variant
            ImVec2 pts[5] = {
                ImVec2(c.x - 6.8f * s, c.y - 10.1f * s),
                ImVec2(c.x + 6.8f * s, c.y - 10.1f * s),
                ImVec2(c.x + 6.8f * s, c.y + 10.1f * s),
                ImVec2(c.x,             c.y + 3.3f * s),
                ImVec2(c.x - 6.8f * s, c.y + 10.1f * s),
            };
            dl->AddConvexPolyFilled(pts, 5, kIcon);
        } else {
            IconBookmark(dl, c, 11.0f * s, kIcon, 1.9f * s);
        }
    }

    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + h - 1.0f * s));
    return hits;
}

void ResizeGrip(ImVec2 pos)
{
    const float s = g_s;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImU32 col = IM_COL32(110, 110, 110, 255);
    dl->AddLine(ImVec2(pos.x + 26.0f * s, pos.y + 2.0f * s),
                ImVec2(pos.x + 2.0f * s, pos.y + 26.0f * s), col, 2.0f * s);
    dl->AddLine(ImVec2(pos.x + 26.0f * s, pos.y + 12.0f * s),
                ImVec2(pos.x + 12.0f * s, pos.y + 26.0f * s), col, 2.0f * s);
}

} // namespace komi
