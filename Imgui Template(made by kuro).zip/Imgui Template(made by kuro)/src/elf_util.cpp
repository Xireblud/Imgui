#include "elf_util.h"

#include <dlfcn.h>
#include <string>

namespace elfutil {

// For the purposes of resolving an exported symbol, the simplest and most robust
// route on Android is dlopen(..., RTLD_NOLOAD) + dlsym. A fully general
// in-memory ELF dynsym walk is overkill for a stub build; dlsym resolves the
// real export through the dynamic linker.
void* find_export(const char* libname, const char* sym) {
    if (!libname || !sym) return nullptr;

    void* h = dlopen(libname, RTLD_NOW | RTLD_NOLOAD);
    if (!h) h = dlopen(libname, RTLD_NOW);
    if (!h) return nullptr;

    void* p = dlsym(h, sym);
    // Do not dlclose: the calling library must stay mapped for the returned
    // pointer to remain valid for the lifetime of the process.
    return p;
}

}
