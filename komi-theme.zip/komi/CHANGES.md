# Komi — change log

Every edit to the Komi theme is recorded here: what changed, which files it
touched, and the diff.

---

## 2026-11-20 · v0.2.2 — documentation site

**Asked for.** A site with the changelog and the source attached.

**Added**

- `site/index.html`, `site/style.css` — overview page with the panel screenshot,
  download and build instructions.
- `site/build_site.py` — generates `changelog.html` from this file and
  `source.html` from the real files in `komi/`, plus the zip in `site/download/`.

**Not included:** any decompiled or prebuilt native library. No theme source
changed in this revision.

**Verified.** Pages generated and served locally; links resolve.

---

## 2026-11-20 · v0.2.1 — fit all seven categories in the card

**Asked for.** Everything in the reference has to fit inside the card; the
first pass clipped the seventh category at the bottom edge.

**Changed**

- `komi/komi_theme.h` — `kCatHeight` 61 → 55, `kKidHeight` 63 → 55.
- `komi/komi_demo.cpp` — card height 0.805 → 0.815 of the display, list row gap 12 → 8.
- `preview/index.html` — same three values, category label 19 → 18.5 px, item 18.5 → 18 px.

**Diff**

```diff
- constexpr float kCatHeight = 61.0f;
- constexpr float kKidHeight = 63.0f;
+ constexpr float kCatHeight = 55.0f;
+ constexpr float kKidHeight = 55.0f;
```

```diff
- ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.0f, 12.0f));
+ ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.0f, 8.0f));
```

**Verified.** `komi_theme.cpp` compiles with `-Wall -Wextra` (0 warnings);

the demo passes a syntax check. No native window was run in this sandbox.

---

## 2026-11-20 · v0.2.0 — redesigned to the card + accordion reference

**Asked for.** Redesign again, accurately to the second reference image: white
page, one dark card, header with avatar/title/version/icons/accent button, a
tab strip with a grey active pill, and collapsible category rows with nested
icon rows.

**Changed**

- `komi/komi_theme.h` — palette replaced (pink/sidebar gone; `kPage`, `kCard`,
  `kRowBg`, `kKidBg`, `kPill`, `kAccent` added). API replaced: `Page`,
  `CardBackground`, `Header`, `TabBar`, `CategoryRow`, `ItemRow`,
  `ResizeGrip`. New `HeaderHits` / `ItemHits` structs.
- `komi/komi_theme.cpp` — all drawing rewritten: header bar with gradient
  avatar, chevron after the title, dim version tag, four icon buttons
  (bookmark, mail, panel, gear) and a right-aligned accent button; tab strip
  that distributes tabs with equal gaps and paints the active pill; category
  row with chevron, 19 px label and right-aligned count; nested item row with
  bookmark + gear hit targets; diagonal resize grip.
- `komi/komi_demo.cpp` — card centred at 83.5% width / 80.5% height, header,
  tabs, then a scrollable list of seven categories (first one open).
- `preview/index.html` — static mock rebuilt to match.

**Values taken from the reference**

- Page `#FFFFFF`; card `#0C0C0C` at radius 16; header hairline `#1F1F1F`
- Category row `#131313` with `#232323` border, height 61, radius 12
- Nested row `#0F0F0F`, height 63, separator `#1E1E1E`, indented 32 px
- Active tab pill `#2A2A2A`, radius 10, height 48; accent button `#5865F2`, radius 10, height 44
- Type ramp: title 26 px bold, tab 17 px semibold, category 19 px semibold, item 18.5 px, count 18 px

**Content** — still neutral app settings (Layouts, Shortcuts, Panels,
Appearance, Diagnostics, Workspaces, Plugins). No game-process code, no
hooking, no memory patching.

**Diff** (public surface):

```diff
- void ApplyTheme(float ui_scale = 1.0f);
- void Title(const char* title, const char* subtitle);
- void SectionLabel(const char* text);
- bool SliderRow(const char* label, float* value, float v_min, float v_max,
-                const char* fmt = "%.1f");
- bool ToggleRow(const char* label, bool* value);
- int  Sidebar(const char* name, const char* subtitle,
-              const char* const* items, int count,
-              int selected, char* search, std::size_t search_size,
-              ImVec2 size);
+ void ApplyTheme(float ui_scale = 1.0f);
+ void Page(ImVec2 display_size);
+ void CardBackground(ImVec2 pos, ImVec2 size);
+ HeaderHits Header(const char* title, const char* version,
+                   ImVec2 pos, float width, const char* action_label);
+ int  TabBar(ImVec2 pos, float width, const char* const* tabs, int count, int selected);
+ bool CategoryRow(const char* label, int count, bool open);
+ ItemHits ItemRow(const char* label, bool bookmarked, bool first, bool last);
+ void ResizeGrip(ImVec2 pos);
```

---

## 2026-11-20 · v0.1.0 — initial build (pink two-card design)

Superseded by v0.2.0; kept for history.

- `komi/komi_theme.h`, `komi/komi_theme.cpp`, `komi/komi_demo.cpp`, `komi/CMakeLists.txt` added.
- Palette: backdrop `#FF3DAE`, sidebar `#171717`, content `#0B0B0B`,
  rows `#2B2B2B` borders, rail `#464646`.
- API: `ApplyTheme`, `Title`, `SectionLabel`, `SliderRow`, `ToggleRow`, `Sidebar`.

---

<!-- Template for the next entry:

## YYYY-MM-DD · vX.Y.Z — <short title>

**Asked for.** <the request in one line>

**Changed**
- `file` — <what changed and why>

```diff
--- a/komi/komi_theme.cpp
+++ b/komi/komi_theme.cpp
@@ ...
- old
+ new
```

**Verified.** <what was compiled or checked>
-->
