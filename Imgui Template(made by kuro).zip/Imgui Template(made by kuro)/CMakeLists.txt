cmake_minimum_required(VERSION 3.20)
project(vr_menu_template LANGUAGES C CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(IMGUI_DIR "${CMAKE_SOURCE_DIR}/deps/imgui")
add_library(vr_menu_template SHARED
 src/main.cpp src/elf_util.cpp src/inline_hook.cpp src/xr_hook.cpp
 src/menu.cpp src/player_features.cpp src/ui_audio.cpp
 ${IMGUI_DIR}/imgui.cpp ${IMGUI_DIR}/imgui_draw.cpp
 ${IMGUI_DIR}/imgui_tables.cpp ${IMGUI_DIR}/imgui_widgets.cpp
 ${IMGUI_DIR}/backends/imgui_impl_vulkan.cpp)
target_include_directories(vr_menu_template PRIVATE src ${IMGUI_DIR} ${IMGUI_DIR}/backends)
target_link_libraries(vr_menu_template PRIVATE log android vulkan dl aaudio)
set_target_properties(vr_menu_template PROPERTIES PREFIX "" OUTPUT_NAME "vr_menu_template")
