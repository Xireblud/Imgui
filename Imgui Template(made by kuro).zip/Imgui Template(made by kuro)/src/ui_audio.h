#pragma once

namespace ui_audio {

enum class Cue { Open, Close, Hover, Select };

void play(Cue cue);
bool enabled();
void set_enabled(bool enabled);
void shutdown();

} // namespace ui_audio
